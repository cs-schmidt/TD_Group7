package towerManager;
import java.util.Scanner;
import player.Player;
import mapsManager.Grids;
import mapsManager.Map;
import enemyManager.*;
public class TowerMap {
	//Attributes
		public Tower[][] towerMap;
		public int[][] towerTracker;
		public int killScore;
	//Constructor
		public TowerMap(Map map){//See later if you can make the other tiles null?
				towerMap = new Tower[map.getMapRows()][map.getMapColumns()];
					for(int row = 0; row < towerMap.length; row++) {
						for(int column = 0; column < towerMap[0].length; column++ ) {
							Tower dummyTower = new Tower('D');
							towerMap[row][column] = dummyTower;
						}
					}
				towerTracker = map.getMapGrid();
					for(int row = 0; row < towerTracker.length; row++) {
						for(int column = 0; column < towerTracker[0].length; column++ ) {
							if(towerTracker[row][column] == 1) {
								towerTracker[row][column] = 0;
							}
							else
								towerTracker[row][column] = -1;
						}
					}
		}
	//Methods
		public void placeTowerGUI(int row, int column) {//Update for dynamic placement.
			if(towerMap[row][column].getTowerTag() > 0) {
				//Do nothing, update for later
			}
			if(towerMap[row][column].getTowerTag() == 0) {
				Tower towerA = new Tower('A');
				towerMap[row][column] = towerA;
				towerTracker[row][column] = 1;
			}
		}
		public int getKillScore() {
			int KillScore = killScore;
			return KillScore;
		}
		public int[][] copyTowerTracker(){
			return Grids.getGridCopy(towerTracker);
		}
		public void towerShoot(EnemyMap enemyMap,Player player){//Improve this.
			for(int row = 0; row < this.towerMap.length; row++) {
				for(int column = 0; column < this.towerMap[0].length; column++ ) {
					if(this.towerMap[row][column].getTowerTag() > 0) {
						for(int tile = enemyMap.getEnemyPathLength()- 2; tile >= 0; tile--) { 
							if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyTag() > 0) { //explore the +0.1 concept later.
								if(distance(enemyMap.enemyPath[tile][0],enemyMap.enemyPath[tile][1],row,column) <= ((double)this.towerMap[row][column].getTowerRange())*Math.pow(2.0,(1.0/2))+.01) {
									enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].setEnemyHealth(this.towerMap[row][column].getTowerDamage());
									if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyHealth() <= 0) {
										Enemy dummyEnemy = new Enemy('D');
										killScore++;
										player.depositFunds(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyValue());
										enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]] = dummyEnemy;
									}
									break;
								}
							}	
						}
					}
				}
			}
		}
		private double distance(double enemyRow, double enemyColumn, double towerRow, double towerColumn) {
			double distance = Math.pow((Math.pow(((double)enemyRow-(double)towerRow),2) + Math.pow(((double)enemyColumn-(double)towerColumn),2)),(((double)1)/2));
			return distance;
		}						
		//Methods specific to the text-based version.
			//1)
			public static void towerMapInfo() {
				System.out.println("*HOW TO PLACE TOWERS: ");
				System.out.println(" To place towers enter the coordinates in the form '0,1', ");
				System.out.println(" where the first number represents the row and the second the column on the map.");
				System.out.println(" You may place towers on the tiles baring the symbol '#' or delete a tower on a tile that bares a letter.*(other than 's' or 'e')");
				System.out.println();
			}
			//2)
			public boolean placeTowerTestMethod() {
				boolean aValidAnswer = false;
				boolean goAhead = false;
				System.out.println("Do you wish to place and/or delete any towers?(yes/no) ");
				Scanner input = new Scanner(System.in);
				String answer = input.nextLine();
				while(aValidAnswer == false) {
					if(answer.equals("yes") ^ answer.equals("no")) {
						aValidAnswer = true;
						if(answer.equals("yes"))
							goAhead = true;
						else
							goAhead = false;
					}
					else {
						System.out.println("Your answer must strictly be 'yes' or 'no'. Reenter 'yes' or 'no': ");
						input = new Scanner(System.in);
						answer = input.nextLine();
						if(answer.equals("yes") ^ answer.equals("no"))
							aValidAnswer = true;
						if(answer.equals("yes"))
							goAhead = true;
						else
							goAhead = false;
					}
				}
				return goAhead;
			}
			//3)
			private int[] getUserInput() {
				int[] coordinates = new int[2];
					coordinates[0] = -1;
					coordinates[1] = -1;
				boolean commaPresent = false;
				int commaIndex = 0;
				String num1 = "";
				String num2 = "";
				boolean userEnteredCorrectly = false;
				while(userEnteredCorrectly == false){
					System.out.println("Enter the coordinates where you wish to place or delete a tower: ");
					Scanner input = new Scanner(System.in);
					String coords = input.nextLine();
					for(int x = 0; x < coords.length(); x++) {
						if(coords.charAt(x) == ',') {
							commaPresent = true;
							commaIndex = x;
							break;
						}
					}
					if(commaPresent == true) {
						try {
							for(int x = 0; x < commaIndex; x++) {
								num1 += coords.charAt(x);
							}
							coordinates[0] = Integer.parseInt(num1);
						}
						catch(Exception e) {
		
						}
						try {
							for(int x = commaIndex + 1; x < coords.length(); x++) {
								num2 += coords.charAt(x);
							}
							coordinates[1] = Integer.parseInt(num2);
							}
						catch(Exception e) {
							
						}
					}
					else
						System.out.println("Your input is not what is expected. enter something like '0,0' as an input");
					if( (coordinates[0] >= 0 && coordinates[0] < towerMap.length) && (coordinates[1] >= 0 && coordinates[1] < towerMap[0].length)) {
						userEnteredCorrectly = onRoad(coordinates);
					}
				}
				return coordinates;
			}
			//4)
			private boolean onRoad(int[] coordinates) {
				boolean notOnRoad = true;
				if(towerTracker[coordinates[0]][coordinates[1]] == -1) {
					System.out.println("It appears you've placed a tower on the road, reenter valid coordinates.");
					notOnRoad = false;
				}
				else
					notOnRoad = true;
				return notOnRoad;
			}
			//5)
			private int typeValid() {
				boolean validInput = false;
				int towerType = 0;
				while(validInput == false) {
					System.out.println("Place a tower of type 1, 2, or 3");
					Scanner input = new Scanner(System.in);
					String answer = input.nextLine();
					try {
						towerType = Integer.parseInt(answer);
						if(towerType == 1 ^ towerType == 2 ^ towerType == 3) {
							validInput = true;
						}
					}
					catch(Exception NumberFormatException) {
						System.out.println("You may only enter a single digit.");
					}
				}
				return towerType;
			}
			//6)
			public void placeTower() { 
				if(placeTowerTestMethod() == true) {
					boolean areYouDone = false;
					System.out.println("you may pick rows between 0 and "+(towerMap.length - 1)+".");
					System.out.println("you may pick columns between 0 and "+(towerMap[0].length -1)+".");
					do {
						int[] coordinates = getUserInput();//Here***
						if(towerTracker[coordinates[0]][coordinates[1]] > 0) {
							Tower dummyTower = new Tower('D');
							towerMap[coordinates[0]][coordinates[1]] = dummyTower;
							towerTracker[coordinates[0]][coordinates[1]] = 0;
							System.out.println("Tower has succesfully been deleted.");
						}
						else {
							int towerType = typeValid();
							if(towerType == 1) {
								Tower towerA = new Tower('A');
								towerMap[coordinates[0]][coordinates[1]] = towerA;
							    towerTracker[coordinates[0]][coordinates[1]] = towerA.getTowerTag();
								System.out.println("Tower type A succesfully placed!");
							}
							if(towerType == 2) {
								Tower towerB = new Tower('B');
								towerMap[coordinates[0]][coordinates[1]] = towerB;
							    towerTracker[coordinates[0]][coordinates[1]] = towerB.getTowerTag();
							    System.out.println("Tower type B succesfully placed!");
							}
							if(towerType == 3) {
								Tower towerC = new Tower('C');
								towerMap[coordinates[0]][coordinates[1]] = towerC;
							    towerTracker[coordinates[0]][coordinates[1]] = towerC.getTowerTag();
							    System.out.println("Tower type C succesfully placed!");
							}
						}
						areYouDone = placeTowerTestMethod();
					}while(areYouDone == true);
				}
			}
}
