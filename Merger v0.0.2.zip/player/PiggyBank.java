package player;
public class PiggyBank {
	//Attributes
	private int funds = 0;
	//Constructor
		public PiggyBank(int initializeFunds) {
			if(initializeFunds >= 0)
				funds = initializeFunds;
			else
				funds = 10;
		}
	//Methods
		//Verification Methods
			private boolean sufficientFunds(int amount) {//Exclusive use for withdrawal
				if((funds - amount) >= 0)
					return true;
				else
					return false;
			}
		//Getters
			public int getFunds() {
				int aCopyOfFunds = funds;
				return aCopyOfFunds;
			}
		//Setters
			public void withdrawFunds(int amount) {//Towers will withdraw funds
				if(sufficientFunds(amount))
					funds -= amount;
				else
					System.out.println("You lack the funds to build that");
			}
			public void depositFunds(int amount) {//Enemies will deposit funds
				funds += amount;
			}
}