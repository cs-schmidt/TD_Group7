package enemyManager;
import java.util.ArrayList;
import java.util.Collections;
public class EnemyBag {
	//Attributes
		private ArrayList<Enemy> bagOfEnemies = new ArrayList<Enemy>();
	//Constructors
		public EnemyBag(){
		}
	//Methods
		//Getters
			public ArrayList<Enemy> getBag(){//This doesn't need to be encapsulated.
				return bagOfEnemies;
			}
		//Setters
			public void setEnemyBag(int round){
				for(int a = 0; a < enemyFunctionA(round); a++) {
					Enemy enemyA = new Enemy('A');
					bagOfEnemies.add(enemyA);
				}
				for(int b = 0; b < enemyFunctionB(round); b++) {
					Enemy enemyB = new Enemy('B');
					bagOfEnemies.add(enemyB);
				}
				for(int c = 0; c < enemyFunctionC(round); c++) {
					Enemy enemyC = new Enemy('C');
					bagOfEnemies.add(enemyC);
				}
				Collections.shuffle(bagOfEnemies);
			}
		//Spawn functions
			private int enemyFunctionA(int round) {//Make this dynamic to A and based on the round number
				return 3 + round;
			}
			private int enemyFunctionB(int round) {//Make this dynamic to B and based on the round number
				return (int)Math.floor(round);
			}
			private int enemyFunctionC(int round) {//Make this dynamic to C and based on the round number
				return (int)Math.floor(round/2);
			}

}
