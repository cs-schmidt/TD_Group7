package GUIversion2;
import javafx.stage.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class InfoPopUp {
 public static final String instuctions = 
		 "This is a TOWER DEFENCE(TD) game. \n"
		 +"You are on a nice picnic with your family, but Oh No! the Insects are attacking!"
		 + " Place towers and fight against a small variety of insects who want to steal"
		 + " your food! Defeat a multitude of increasingly difficult waves of insects "
		 + "before they reach the end and ruin your picnic. \n"
		 + "This Project was completed by: \n"
		 + "Edrick Lin. \nAlex (ZiXi Han). \nBruce(ZheZheng Wong). \nEthan Schmidt.";
	
	public static void mainmenu_display() {
		Stage window = new Stage();
		
		//MODALITY
		window.initModality(Modality.APPLICATION_MODAL);
		
		//SETTING UP LABEL AND BUTTON FUCTION
		Label label = new Label();
		label.setText(instuctions);
		label.setWrapText(true);
		Button closeButton = new Button("Very Interesting");
		closeButton.setOnAction(e -> window.close());
			
		//VBOX FOR BUTTON
		VBox layout = new VBox(10);
		layout.getChildren().addAll(label, closeButton);
		layout.setAlignment(Pos.CENTER);
		
		//IMAGING THE BACKGROUND
		Image background = new Image("info_background.png", true);
		ImageView node_background = new ImageView();
		node_background.setImage(background);
		
		//STACKPANE TO STACK BACKGROUND
		StackPane layout_p = new StackPane();
		layout_p.getChildren().addAll(node_background, layout);
		
		//SCENE CREATION
		Scene scene = new Scene(layout_p,500,400);
		window.setTitle("PRELUDE & CREDITS");
		window.setScene(scene);
		window.showAndWait();
	}
	
	public static void game_info() {
		Stage window = new Stage();
		
		//SETTING UP LABEL AND BUTTON FUCTIO
		
		
		Image enemy_b_pic = new Image("BugInfoButton.png",150,50,false,true);
		ImageView node_enemy = new ImageView(enemy_b_pic);
		Image towers_b_pic = new Image("TowerInfoButton.png",150,50,false,true);
		ImageView node_towers = new ImageView(towers_b_pic);
		Image gameplay_pic = new Image("GamePlayButton.png",150,50,false,true);
		ImageView node_gameplay = new ImageView(gameplay_pic);
		
		Button enemy = new Button();
		enemy.setGraphic(node_enemy);
		enemy.setPadding(Insets.EMPTY);
		
		Button towers = new Button();
		towers.setGraphic(node_towers);
		towers.setPadding(Insets.EMPTY);
		
		Button game_play = new Button();
		game_play.setGraphic(node_gameplay);
		game_play.setPadding(Insets.EMPTY);
				
		//VBOX FOR BUTTON and descriptions
		VBox layout = new VBox(10);
		layout.setSpacing(20);
		layout.getChildren().addAll(enemy,towers,game_play);
		layout.setAlignment(Pos.CENTER);	
		
		//IMAGING THE BACKGROUND
		Image background = new Image("info_background.png", true);
		ImageView node_background = new ImageView();
		node_background.setImage(background);
		
		//STACKPANE TO STACK BACKGROUND
		StackPane layout_p = new StackPane();
		layout_p.getChildren().addAll(node_background, layout);
		
		
		// SCENES
		Image back_pic = new Image("backButton.png",50,30,false,true);
		ImageView node_back = new ImageView(back_pic);
		
		Button back1 = new Button();
		back1.setGraphic(node_back);
		back1.setPadding(Insets.EMPTY);
		Pane enemy_b = new Pane();                              
		enemy_b.getChildren().addAll(back1);  //ADD IMAGE DESCRIPTION OF ENEMY FIRST
		back1.setLayoutX(120);
		back1.setLayoutY(270);	
		Scene enemy_s = new Scene(enemy_b,300,300);
		
		Button back2 = new Button();
		back2.setGraphic(node_back);
		back2.setPadding(Insets.EMPTY);
		Pane towers_b = new Pane();
		towers_b.getChildren().addAll(back2);                                    //ADD IMAGE DESCRIPTION OF TOWERS
		back2.setLayoutX(120);
		back2.setLayoutY(270);
		Scene towers_s = new Scene(towers_b,300,300);
		
		Button back3 = new Button();
		back3.setGraphic(node_back);
		back3.setPadding(Insets.EMPTY);
		Pane gameplay_b = new Pane();
		gameplay_b.getChildren().addAll(back3);  
		back3.setLayoutX(120);
		back3.setLayoutY(270);																	//ADD IMAGE DESCRIPTION OF GAMEPLAY
		Scene gameplay_s = new Scene(gameplay_b,300,300);
		
		
		
		//SCENE CREATION
		Scene main_scene = new Scene(layout_p,300,300);
		
		back1.setOnAction(e -> window.setScene(main_scene));
		back2.setOnAction(e -> window.setScene(main_scene));
		back3.setOnAction(e -> window.setScene(main_scene));
		enemy.setOnAction(e -> window.setScene(enemy_s));
		towers.setOnAction(e -> window.setScene(towers_s));
		game_play.setOnAction(e -> window.setScene(gameplay_s));
		
		window.setTitle("INFO");
		window.setScene(main_scene);
		window.showAndWait();
	}
	
	
	
	
	
	
	
	
	
	 
	public static void tower_placement() {
		Stage window = new Stage();
	
		//SETTING UP LABEL AND BUTTON FUCTION
		Button closeButton = new Button("Close");
		closeButton.setOnAction(e -> window.close());
		
		//TOWER BUTTONS
		Image tower1_pic = new Image("Tower01.png");
		ImageView node_tower1 = new ImageView(tower1_pic);
		Button tower1 = new Button();
		tower1.setGraphic(node_tower1);
		
		Image tower2_pic = new Image("Tower02.png");
		ImageView node_tower2 = new ImageView(tower2_pic);
		Button tower2 = new Button();
		tower2.setGraphic(node_tower2);
		
		Image tower3_pic = new Image("Tower03.png");
		ImageView node_tower3 = new ImageView(tower3_pic);
		Button tower3 = new Button();
		tower3.setGraphic(node_tower3);
		
		//TOWER DESCRIPTIONS
		
		
		
			
		//VBOX FOR BUTTON and descriptions
		VBox layout = new VBox(10);
		layout.getChildren().addAll(closeButton);
		layout.setAlignment(Pos.BASELINE_LEFT);
	
		//IMAGING THE BACKGROUND
		Image background = new Image("info_background.png", true);
		ImageView node_background = new ImageView();
		node_background.setImage(background);
		
		//STACKPANE TO STACK BACKGROUND
		Pane layout_p = new Pane();
		layout_p.getChildren().addAll(node_background, layout);
		
		//SCENE CREATION
		Scene scene = new Scene(layout_p,300,300);
		window.setTitle("TOWERS");
		window.setScene(scene);
		window.showAndWait();
	}

	
	
	
	
}
