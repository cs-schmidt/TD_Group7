package GUIversion2;

import enemyManager.EnemyMap;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import mapsManager.Map;
import player.Player;
import towerManager.TowerMap;

public class Controller {
	public static DoubleProperty dp;//See this***
	public static void seeTowerLayer(TowerMap towerMap, GridPane towerMapLayer) {
		towerMapLayer.getChildren().clear();
		for(int row = 0; row < towerMap.towerMap.length; row++) {
			for(int column = 0; column < towerMap.towerMap[0].length; column++) {
				if(towerMap.towerTracker[row][column] == 1) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower1 = new Image("Tower01.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower1));
					towerMapLayer.add(towerIcon,column,row);
				}
				else if(towerMap.towerTracker[row][column] == 2) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower2 = new Image("Tower02.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower2));
					towerMapLayer.add(towerIcon,column,row);
				}
				else if(towerMap.towerTracker[row][column] == 3) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower3 = new Image("Tower03.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower3));
					towerMapLayer.add(towerIcon,column,row);
				}
				else {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					towerIcon.setOpacity(0.1);
					towerMapLayer.add(towerIcon,column,row);
				}
			}
		}
	}
	public static void setEnemyPlayer(EnemyMap enemyMap,GridPane enemyPlayer) {//You could make the double for loop road specific.
		//enemyPlayer.getChildren().clear();
		for(int row = 0; row < enemyMap.enemyMap.length; row++) {
			for(int column = 0; column < enemyMap.enemyMap[0].length; column++) {
				if(enemyMap.enemyMap[row][column].getEnemyTag() == 1) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug1 = new Image("Bug1.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug1));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else if(enemyMap.enemyMap[row][column].getEnemyTag() == 2) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug2 = new Image("Bug2.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug2));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else if(enemyMap.enemyMap[row][column].getEnemyTag() == 3) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug3 = new Image("Bug3.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug3));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					enemyMarker.setFill(Color.RED);
					enemyMarker.setOpacity(0.1);
					enemyPlayer.add(enemyMarker, column, row);
				}
			}
		}
	}
	public static GridPane setTowerLayer(Map map) {
		GridPane towerMapLayer = new GridPane();
		for(int row = 0; row < map.getMapGrid().length; row++) {
			for(int column = 0; column < map.getMapGrid()[0].length; column++) {
					Circle towerMarker = new Circle();
					towerMarker.setRadius(15);
					towerMarker.setFill(Color.BLACK);
					towerMarker.setOpacity(0.1);
					towerMapLayer.add(towerMarker, column, row);
			}
		}
		return towerMapLayer;
	}
	public static GridPane createTowerMapInteractable(Map map, TowerMap towerMap, GridPane towerMapLayerA, Player player, DoubleProperty dp) {
		GridPane towerMapLayer = new GridPane();
		for(int row = 0; row < map.getMapGrid().length;row++) {
			for(int column = 0; column < map.getMapGrid()[0].length; column++) {
				if(map.getMapGrid()[row][column] == 1) {
					TowerMapButton towerMapButton = new TowerMapButton(row, column, towerMap, towerMapLayerA, player, dp);
					towerMapLayer.add(towerMapButton, column, row);
				}
				else {
					Rectangle spaceFiller = new Rectangle(30,30);//Here is a Change
					spaceFiller.setOpacity(0);
					towerMapLayer.add(spaceFiller, column, row);
				}
			}
		}
		return towerMapLayer;
	}
	public static GridPane createMapUnderlier(Map map) {
		GridPane mapUnderlier = new GridPane();
		for(int row = 0; row < map.getMapGrid().length;row++) {
			for(int column = 0; column < map.getMapGrid()[0].length; column++) {
				if(map.getMapGrid()[row][column] == 1) {
					BackgroundTile tile = new BackgroundTile();
					mapUnderlier.add(tile, column, row);
				}
				else {
					BackgroundTile tile = new BackgroundTile();
					Image road = new Image("road_2.png",30,30,false,true);
					tile.setFill(new ImagePattern(road));
					mapUnderlier.add(tile, column, row);
				}
			}
		}
		return mapUnderlier;
	}

	}
class TowerMapButton extends Button{//Button class
	int row;
	int column;
	//Alright for this constructor be sure to add a new implementation of setOnAction.
	TowerMapButton(int row, int column,TowerMap towerMap, GridPane towerMapLayer, Player player, DoubleProperty dp){//Give the button specific capabilities Later on.
		setPrefSize(30,30);
		setOpacity(0.1);//Change later if needed.
		this.row = row;
		this.column = column;//We'll find another way to display towers.
		setOnMouseClicked(e->{//Of course account for player funds later.
			if(e.getButton()==MouseButton.PRIMARY) {//Delete function here or just do nothing if tower is there.***
				towerMap.placeTowerGUI(this.row, this.column,'A', player);
				dp.setValue(player.getFunds());
			}
			else if(e.getButton()==MouseButton.SECONDARY) {
				towerMap.placeTowerGUI(this.row, this.column,'B', player);
				dp.setValue(player.getFunds());
			}
			else if(e.getButton()==MouseButton.MIDDLE) {//This is where you will have to tinker.
				towerMap.deleteTowerGUI(this.row, this.column, player);
				dp.setValue(player.getFunds());
			}
			Controller.seeTowerLayer(towerMap, towerMapLayer);
		});
	}
}
class BackgroundTile extends Rectangle{
	BackgroundTile(){
		Image grass = new Image("grassLand.png",29,29,false,true);
		setWidth(29);
		setHeight(29);
		setStrokeWidth(1);
		setStroke(Color.GREEN);
		setFill(new ImagePattern(grass));
	
}
}