package altMapsB;

public class Map {

}
