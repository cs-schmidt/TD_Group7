package playGame;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class TileBackground extends Rectangle {

	public TileBackground(int rows, int columns) {
		setWidth(Main.tileSize);
		setHeight(Main.tileSize);
		relocate(rows*Main.tileSize, columns*Main.tileSize);
	}
	
	public void distinguish(int[][] validiyMapUnderlier,int column,int row) {
		if((column + row) % 2 == 1 && validiyMapUnderlier[column][row] == 1 ) {
			setFill(Color.LIGHTGREEN);
		}
		else if((column + row) % 2 == 0 && validiyMapUnderlier[column][row] == 1 ) {
			setFill(Color.GREEN);
		}
		else if(validiyMapUnderlier[column][row] == 2 ) {
			setFill(Color.ORANGE);
		}
		else if(validiyMapUnderlier[column][row] == 3 ) {
			setFill(Color.RED);
		}
		else if((column + row) % 2 == 0 && validiyMapUnderlier[column][row] == 0 ) {
			setFill(Color.LIGHTGREY);
		}
		else if((column + row) % 2 == 1 && validiyMapUnderlier[column][row] == 0 ) {
			setFill(Color.GREY);
		}
	}
}
