package gameRunner;
import towerManager.Tower;
import towerManager.TowerMap;
import enemyManager.EnemyBag;
import enemyManager.EnemyMap;
import player.Player;
public class DevelopLogic {//Play around with the logic here.
	
	//Set the enemyBag
	public static int stepCalculator(TowerMap towerMap, EnemyMap bagCopy, Player you, int round) {//This will be the life-blood of the game
		TowerMap towerMapC = new TowerMap(towerMap);
		EnemyMap bagCopyC = new EnemyMap(bagCopy);
		Player youC = new Player(you);
		int steps = 0;
		//bagCopy.setEnemyBag(round);//Here
		bagCopyC.getBag();
		do {
			if(bagCopyC.getBag().size() > 0) {
				bagCopyC.spawnEnemy();
			}
			//Enemy spawns
			towerMapC.towerShoot(bagCopyC,youC);
			//Towers Shoot
			bagCopyC.moveEnemies(youC);
			steps++;
			//Enemies move
		}while(bagCopyC.checkForEnemiesPresent() == true && youC.getPlayerHealth() > 0);
		return steps;
	}
}
