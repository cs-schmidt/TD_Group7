package GUI_TEST;

import enemyManager.EnemyMap;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import mapsManager.Map;
import mapsManager.Maps;
import player.Player;
import towerManager.TowerMap;

public abstract class Main extends Application{
	//Try this
	static GridPane enemyMapLayer;
	static GridPane towerMapLayer;
	static TowerMap towerMap;
	static Player you;
	static int round = 0;
	static Button startButton;
	static int mapIndex;
	//e
	public static void main(String[]args) {
		launch(args);
	}
	
	public static void start(Stage stage, int x) throws Exception {
		//Load some map
		mapIndex = x;
		you = new Player(2);
		Maps maps = new Maps();
		towerMap = new TowerMap(maps.getMap(x));
		//e
		//Establish panes
		BorderPane masterPane = new BorderPane();
		Pane topPane = new Pane();
		Pane rightPane = new Pane();
		StackPane gamePane = new StackPane();
		GridPane mapUnderlier = Controller.createMapUnderlier(maps.getMap(x));
		enemyMapLayer = new GridPane();
		towerMapLayer = Controller.setTowerLayer(maps.getMap(x));
		GridPane towerMapInteractable = Controller.createTowerMapInteractable(maps.getMap(x),towerMap, towerMapLayer, you);//This part is bugging out.***
		//e
		//Setup layout of things in the masterPane
		masterPane.setTop(topPane);
		masterPane.setRight(rightPane);
		masterPane.setCenter(gamePane);
		//e
		//Set all dimensions
		topPane.setPrefSize(800, 200);
		rightPane.setPrefSize(200, 600);
		gamePane.setPrefSize(600, 600);
		//e
		//Additional features to the rightPane
		Rectangle rightPaneBackground = new Rectangle();
		rightPaneBackground.setWidth(200);
		rightPaneBackground.setHeight(600);
		rightPaneBackground.setFill(Color.TEAL);
		rightPane.getChildren().add(rightPaneBackground);
		startButton = new Button("Start");
		startButton.setAlignment(Pos.CENTER);
		rightPane.getChildren().add(startButton);
		//e
		//Additional features for the topPane
		Rectangle topPaneBackground = new Rectangle();
		topPaneBackground.setWidth(800);
		topPaneBackground.setHeight(200);
		topPaneBackground.setFill(Color.FIREBRICK);
		topPane.getChildren().add(topPaneBackground);
		//e
		//Order gamePane
		gamePane.getChildren().addAll(mapUnderlier, enemyMapLayer, towerMapLayer, towerMapInteractable);
		//e
		//Load Stage & Scene
		Scene scene = new Scene(masterPane, 800, 800);
		stage.setScene(scene);
		stage.show();
		//e
		//SetUp button action here
		startButton.setOnAction(e ->{
			runThreadedTask();
			System.out.println("The button did your bidding");
		});
		//e
	}
	public static void runThreadedTask() {//So the logic must be confined to this area.
		startButton.setDisable(true);
		Maps maps = new Maps();
		EnemyMap enemyMap = new EnemyMap(maps.getMap(mapIndex));
		enemyMap.setEnemyBag(round);
		Thread thread = new Thread(new Task<Void>(){//First spawn doesn't show because we have to have a display up here, easily fixable.
			@Override
			protected Void call() throws Exception {
				do{
					if(enemyMap.getBag().size() > 0) {
						enemyMap.spawnEnemy();
					}
					towerMap.towerShoot(enemyMap, you);
					Platform.runLater(new Runnable() {
						@Override
						public void run() {//So it seems the multiple runs may work.
							enemyMapLayer.getChildren().clear();
							Controller.setEnemyPlayer(enemyMap, enemyMapLayer);
						}
					});
					Thread.sleep(500);//Just to space it out.
					enemyMap.moveEnemies(you);
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							enemyMapLayer.getChildren().clear();
							Controller.setEnemyPlayer(enemyMap, enemyMapLayer);
						}
					});
					Thread.sleep(500);
				}while(enemyMap.checkForEnemiesPresent()==true && you.getPlayerHealth() > 0);
				round++;//Round is going up.
				System.out.println("wave: "+round);
				startButton.setDisable(false);//You could make the task return something to set a timer on disable?
				return null;
			}
		});
		Thread newT = new Thread(thread);
	    newT.setDaemon(true);
	    newT.start();
	}
}
