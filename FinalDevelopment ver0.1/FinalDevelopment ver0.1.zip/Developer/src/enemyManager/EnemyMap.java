package enemyManager;
import mapsManager.Grids;
import mapsManager.Map;
import player.Player;
public class EnemyMap extends EnemyBag{//I think EnemyMap can inherit EnemyBag, just remember to call EnemyBags methods on this object now.
	//Attributes
		public Enemy[][] enemyMap;
		public int[][] enemyPath;
	//Constructor
		public EnemyMap(Map map){//See later if you can make the other tiles null?
			enemyMap = new Enemy[map.getMapRows()][map.getMapColumns()];
			for(int row = 0; row < enemyMap.length; row++) {
				for(int column = 0; column < enemyMap[0].length; column++ ) {
					Enemy dummyEnemy = new Enemy('D');
					enemyMap[row][column] = dummyEnemy;
				}
			}
			enemyPath = map.getMapRoad();
		}
		public EnemyMap(EnemyMap toCopy) {//Copy constructor
			super(toCopy);
			enemyMap = new Enemy[toCopy.enemyMap.length][toCopy.enemyMap[0].length];
			for(int row = 0; row < enemyMap.length; row++) {
				for(int column = 0; column < enemyMap[0].length; column++ ) {
					Enemy enemyCopy = new Enemy(toCopy.enemyMap[row][column]);
					enemyMap[row][column] = enemyCopy;
				}
			}
			enemyPath = Grids.getGridCopy((toCopy.enemyPath));
		}
	//Methods
		//Other methods
			public boolean checkForEnemiesPresent() {
				boolean enemiesPresent = false;
				for(int i = 0; i < this.enemyMap.length; i++) {
					for(int j = 0; j < this.enemyMap[i].length; j++) {
						if(this.enemyMap[i][j].getEnemyTag() > 0) {
							enemiesPresent = true;
							break;
						}
					}
					if(enemiesPresent == true) {
						break;
					}
				}
				return enemiesPresent;
			}
		//Basically setters.
			public void spawnEnemy() {//All along the logic of extending the bag class.
				int row = enemyPath[0][0];
				int column = enemyPath[0][1];
				enemyMap[row][column] = getBag().get(0);
				getBag().remove(0);
			}
			public void moveEnemies(Player player) {
				for(int row = enemyPath.length - 2; row >= 0; row--) {
					if(enemyMap[enemyPath[row][0]][enemyPath[row][1]].getEnemyTag() > 0) {
						Enemy enemyCopied = new Enemy(enemyMap[enemyPath[row][0]][enemyPath[row][1]]);
						enemyMap[enemyPath[row + 1][0]][enemyPath[row + 1][1]] = enemyCopied;
						Enemy dummyEnemy = new Enemy('D');
						enemyMap[enemyPath[row][0]][enemyPath[row][1]] = dummyEnemy;
						if(enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]].getEnemyTag() > 0){
							player.setPlayerHealth(enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]].getEnemyDamage());
							Enemy dummyEnemyP = new Enemy('D');
							enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]] = dummyEnemyP;
						}
					}
				}
			}
		
			
			//###Shot these methods in the Head.
		//Getters
			public int getEnemyPathLength(){
				return enemyPath.length;
			}	
			public void enemyHealthDisplay() {
				System.out.print("Enemy health: ");
				for(int row = 0; row <  this.enemyPath.length - 1; row++) {
					if(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]].getEnemyTag() > 0) {
						System.out.print(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]].getEnemyHealth() + " ");
					}
				}
			}
}
