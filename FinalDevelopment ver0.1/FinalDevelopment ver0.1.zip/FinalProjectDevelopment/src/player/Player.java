package player;
import java.util.Scanner;
public class Player extends PiggyBank{//I think the player can extend the PiggyBank.
	//Attributes
		int playerHealth = 50;
		String playerName = "player";
	//Constructor
		public Player(int startingFunds){
			super(startingFunds);
		}
	//Methods
		//Getters
		public int getPlayerHealth() {
			int health = this.playerHealth;
			return health;
		}
		//Setters
 		public void setPlayerHealth(int damage) {
			if(damage >= 0)
				playerHealth = playerHealth - damage;
			else
				;
		}
		public void setPlayerName(String name) {
			playerName = name;
		}
		public void setPlayerName() {//Text-Version exclusive.
			System.out.print("Enter your name: ");
			Scanner input = new Scanner(System.in);
			String name = input.nextLine();
			playerName = name;
		}
}