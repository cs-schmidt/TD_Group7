package enemyManager;
public class Enemy {
	//Attributes
		private int enemyHealth;
		private int enemyDamage;
		private int enemyTag;
		private int enemyValue;
	//Constructors
		public Enemy(char identifier) {
			if(identifier == 'A') {
				enemyHealth = 3;
				enemyDamage = 1;
				enemyTag = 1;
				enemyValue = 1;//Adjust this for balance
			}
			
			else if(identifier == 'B') {
				enemyHealth = 4;
				enemyDamage = 2;
				enemyTag = 2;
				enemyValue = 3;//Adjust this for balance	
			}
			else if(identifier == 'C') {
				enemyHealth = 5;
				enemyDamage = 3;
				enemyTag = 3;
				enemyValue = 4;//Adjust this for balance	
			}
			else {
				enemyHealth = 0;
				enemyDamage = 0;
				enemyTag = 0;
				enemyValue = 0;//Dummy enemy is created
			}
		}
		protected Enemy(int health, int damage, int tag, int value) {//I don't think I need this anymore.
			enemyHealth = health;
			enemyDamage = damage;
			enemyTag = tag;
			enemyValue = value;	
		}	
		protected Enemy(Enemy toCopy) {
			enemyHealth = toCopy.enemyHealth;
			enemyDamage = toCopy.enemyDamage;
			enemyTag = toCopy.enemyTag;
			enemyValue = toCopy.enemyValue;
		}
	//Methods
		//Getters
			public int getEnemyHealth() {
				int health = enemyHealth;
				return health;
			}
			public int getEnemyDamage() {
				int damage = enemyDamage;
				return damage;
			}
			public int getEnemyTag() {
				int tag = enemyTag;
				return tag;
			}
			public int getEnemyValue() {
				int value = enemyValue;
				return value;
			}
		//Setters
			public void setEnemyHealth(int damageRecieved) {
				if(damageRecieved >= 0) {
					enemyHealth = enemyHealth - damageRecieved;
				}
				else
					;//Do Nothing
			}
}
