package player;
public class PiggyBank {
	//Attributes
	private double funds = 0.0;
	//Constructor
		public PiggyBank(double initializeFunds) {
			if(initializeFunds >= 0)
				funds = initializeFunds;
			else
				funds = 10;
		}
		PiggyBank(PiggyBank toCopy){//Copy constructor
			funds = toCopy.funds;
		}
	//Methods
		//Verification Methods
			public boolean sufficientFunds(double amount) {//Exclusive use for withdrawal
				if((funds - amount) >= 0)
					return true;
				else
					return false;
			}
		//Getters
			public double getFunds() {
				double aCopyOfFunds = funds;
				return aCopyOfFunds;
			}
		//Setters
			public void withdrawFunds(double amount) {//Towers will withdraw funds
				if(sufficientFunds(amount))
					funds -= amount;
				else
					System.out.println("You lack the funds to build that");
			}
			public void depositFunds(double amount) {//Enemies will deposit funds
				funds += amount;
			}
}