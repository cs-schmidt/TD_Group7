package game;

import player.Player;

public class Game {
	//Attributes
	private GameMap gameMap;
	private Player you;
	//e
	//Constructor
	public Game(int mapSelected, int startingPlayerFunds){
		gameMap = new GameMap(mapSelected);
		you = new Player(startingPlayerFunds);
	}
	//e
	//Methods
	public GameMap getGameMap() {
		return gameMap;
	}
	public Player getPlayer() {
		return you;
	}
	//e
}
