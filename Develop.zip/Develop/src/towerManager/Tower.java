package towerManager;
public class Tower {//Now I'm thinking to add even more towers so that the outer tiles of a map won't just serve no purpose. 
	//Attributes
		private int towerDamage;
		private int towerRange;
		private int towerTag;
		private double towerCost;
	//Constructors
		Tower(char identifier){
			if(identifier == 'A') {
				towerDamage = 1;//Adjust this for balance
				towerRange = 1;//Adjust this for balance
				towerTag = 1;
				towerCost = 1;//Adjust this for balance
			}
			
			else if(identifier == 'B') {
				towerDamage = 2;//Adjust this for balance	
				towerRange = 2;//Adjust this for balance
				towerTag = 2;
				towerCost = 2;//Adjust this for balance	
			}
			else if(identifier == 'C') {
				towerDamage = 3;//Adjust this for balance	
				towerRange = 3;//Adjust this for balance
				towerTag= 3;
				towerCost = 3;//Adjust this for balance	
			}
			else {
				towerDamage = 0;
				towerRange = 0;
				towerTag = 0;
				towerCost = 0;//Dummy Tower is created
			}
		}
		Tower(int damage, int range, int tag, int cost){
			towerDamage = damage;
			towerRange = range;
			towerTag = tag;
			towerCost = cost;
		}
		Tower(Tower toCopy){//Copy constructor
			towerDamage = toCopy.towerDamage;
			towerRange = toCopy.towerRange;
			towerTag = toCopy.towerTag;
			towerCost= toCopy.towerCost;
		}
	//Methods
		//Getters
			public int getTowerDamage() {
				int damage = towerDamage;
				return damage;
			}
			public int getTowerRange() {
				int range = towerRange;
				return range;
			}
			public int getTowerTag() {
				int tag = towerTag;
				return tag;
			}
			public double getTowerCost() {
				double cost = towerCost;
				return cost;
			}
}
