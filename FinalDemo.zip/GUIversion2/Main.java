package GUIversion2;


import game.Game;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;


public abstract class Main extends Application{
	//The new way:
	static Stage stage;
	static Game game;

	static GridPane enemyMapLayer;
	static GridPane towerMapLayer;
	static Pane shootingLayer;

	
	//static Player you;
	static Button startButton;
	static IntegerProperty roundCounter;
	static IntegerProperty moneyCounter;
	static IntegerProperty killCounter;
	static IntegerProperty healthCounter;
	//e
	public static void main(String[]args) {
		launch(args);
	}
	public static void end_lose(Stage stage) {          
		//loser screen
		Image loser = new Image("Loser.png");
		ImageView node_loser = new ImageView();
		node_loser.setImage(loser);
		StackPane lose = new StackPane();
		lose.getChildren().addAll(node_loser);
		Scene youLose = new Scene(lose,800,800);
		stage.setScene(youLose);
		
	}
	
	public static void start(int mapPicked) throws Exception {
		stage = new Stage();
		game = new Game(mapPicked,3);

		//Establish panes
		BorderPane masterPane = new BorderPane();
		Pane topPane = new Pane();
		Pane rightPane = new Pane();
		HBox top_box = new HBox();
		VBox side_box = new VBox();
		Pane money = new Pane();
		Pane round_b = new Pane();
		Pane health = new Pane();
		Pane kill_counter = new Pane();
		StackPane gamePane = new StackPane();
		GridPane mapUnderlier = Controller.createMapUnderlier(game.getGameMap().maps.getMap(mapPicked));
		enemyMapLayer = new GridPane();
		towerMapLayer = Controller.setTowerLayer(game.getGameMap().maps.getMap(mapPicked));
		shootingLayer = new Pane();
		//e
		moneyCounter = new SimpleIntegerProperty(game.getPlayer().getFunds());//HERE
		GridPane towerMapInteractable = Controller.createTowerMapInteractable(game.getGameMap().maps.getMap(mapPicked), game.getGameMap().getTowerMap(), towerMapLayer, game.getPlayer(), moneyCounter);//This part is bugging out.***
		//e
		//Setup layout of things in the masterPane
		masterPane.setTop(topPane);
		masterPane.setRight(rightPane);
		masterPane.setCenter(gamePane);
		//e
		//Set all dimensions
		topPane.setPrefSize(800, 200);
		rightPane.setPrefSize(200, 600);
		gamePane.setPrefSize(600, 600);
		//e
		
		//Additional features to the rightPane
		Rectangle rightPaneBackground = new Rectangle();
		rightPaneBackground.setWidth(200);
		rightPaneBackground.setHeight(600);
		Image side_bar = new Image("SideBar.png",200,600,false,true);
		rightPaneBackground.setFill(new ImagePattern(side_bar));
		
		//popup info button with enemy classes or tower or how to play
		Image info_pic = new Image("info_button.png",140,50,false,true);
		ImageView node_info = new ImageView(info_pic);
		Button info = new Button();
		info.setGraphic(node_info);
		info.setPadding(Insets.EMPTY);
		info.setOnAction(e -> {
			info.setDisable(true);
			Controller.game_info();
			info.setDisable(false);
		});                                                         
		
		//round counter
		Image round_pic = new Image("RoundCounter.png",150,50,false,true);
		ImageView node_round = new ImageView(round_pic);
		Label round_now = new Label(Integer.toString(game.getRound()));
		round_now.setTextFill(Color.BLACK);
		round_now.setFont(Font.font("Helvetica",FontWeight.BOLD, 25));
		round_now.setLayoutX(112);
		round_now.setLayoutY(10);
		roundCounter = new SimpleIntegerProperty(0);
		round_now.textProperty().bind(roundCounter.asString());
		//e
		round_b.getChildren().addAll(node_round,round_now);
		
		//money side box
		Image money_pic = new Image("GoldMultiplication.png",75,60,false,true);
		ImageView node_money = new ImageView(money_pic);
		Label money_now = new Label(Double.toString(game.getPlayer().getFunds())); // ETHAN CHANGE THIS TO INTEGER
		money_now.setTextFill(Color.BLACK);
		money_now.setFont(Font.font("Helvetica",FontWeight.BOLD, 25));
		money_now.setLayoutX(90);
		money_now.setLayoutY(20);
		
		money_now.textProperty().bind(moneyCounter.asString());
		//e
		money.getChildren().addAll(node_money, money_now);
		
		// kill counter
		Image kill_counter_pic = new Image("BugsKilled.png",60,60,false,true);
		ImageView node_kill_count = new ImageView(kill_counter_pic);
		Label kills_now = new Label(Integer.toString(game.getGameMap().getTowerMap().getKillScore()));
		kills_now.setTextFill(Color.BLACK);
		kills_now.setFont(Font.font("Helvetica",FontWeight.BOLD, 25));
		kills_now.setLayoutX(90);
		kills_now.setLayoutY(20);
		
		killCounter = new SimpleIntegerProperty(0);
		kills_now.textProperty().bind(killCounter.asString());
		//e
		kill_counter.getChildren().addAll(node_kill_count, kills_now);
		
		//health counter
		Image health_pic = new Image("Heart_Multiplication.png",75,60,false,true);
		ImageView node_health = new ImageView(health_pic);
		Label health_now = new Label(Integer.toString(game.getPlayer().getPlayerHealth()));
		health_now.setTextFill(Color.BLACK);
		health_now.setFont(Font.font("Helvetica",FontWeight.BOLD, 25));
		health_now.setLayoutX(90);
		health_now.setLayoutY(20);
		
		healthCounter = new SimpleIntegerProperty(game.getPlayer().getPlayerHealth());
		health_now.textProperty().bind(healthCounter.asString());
		//e
		health.getChildren().addAll(node_health, health_now);
		
		//label
		Label version = new Label("Picnic Defender alpha v 0.0.1");
		version.setTextFill(Color.GREY);
		version.setFont(Font.font("Helvetica",FontWeight.LIGHT, 10));
		
		side_box.getChildren().addAll(info, round_b,money,kill_counter,health,version);
		side_box.setLayoutX(30);
		side_box.setLayoutY(30);
		side_box.setSpacing(50);
		rightPane.getChildren().addAll(rightPaneBackground,side_box);

		//e
		//Additional features for the topPane
		Rectangle topPaneBackground = new Rectangle();
		topPaneBackground.setWidth(800);
		topPaneBackground.setHeight(200);
		Image top_image = new Image("topBar.png",800,200,false,true);
		topPaneBackground.setFill(new ImagePattern(top_image));
		startButton = new Button();
		startButton.setPadding(Insets.EMPTY);
		startButton.setTranslateX(20);
		startButton.setTranslateY(140);
		top_box.getChildren().addAll(startButton);
		Image start_b = new Image("start_b.png",200,40,false,true);
		ImageView node_start = new ImageView(start_b);
		startButton.setGraphic(node_start);
		topPane.getChildren().addAll(topPaneBackground, top_box);
		
		//e
		//Order gamePane
		gamePane.getChildren().addAll(mapUnderlier, enemyMapLayer, towerMapLayer, shootingLayer, towerMapInteractable);
		//e
		//Load Stage & Scene
		Scene scene = new Scene(masterPane, 800, 800);
		stage.setScene(scene);
		stage.show();
		//e
		//SetUp button action here
		startButton.setOnAction(e ->{
			runThreadedTask();
		});
		//e
	}
	public static void runThreadedTask() {//So the logic must be confined to this area.
		startButton.setDisable(true);
		game.getGameMap().getEnemyMap().setEnemyBag(game.getRound());
		Thread thread = new Thread(new Task<Void>(){//First spawn doesn't show because we have to have a display up here, easily fixable.
			@Override
			protected Void call() throws Exception {
				do{
					if(game.getGameMap().getEnemyMap().getBag().size() > 0) {
						game.getGameMap().getEnemyMap().spawnEnemy();
					}
					game.getGameMap().getTowerMap().towerShoot(game.getGameMap().getEnemyMap(), game.getPlayer());
					Platform.runLater(new Runnable() {
						@Override
						public void run() {//So it seems the multiple runs may work.
							Controller.seeShootingLayer(game.getGameMap().getTowerMap(), shootingLayer);
							enemyMapLayer.getChildren().clear();
							Controller.setEnemyPlayer(game.getGameMap().getEnemyMap(), enemyMapLayer);
							killCounter.setValue(game.getGameMap().getTowerMap().getKillScore());
							moneyCounter.setValue(game.getPlayer().getFunds());
						}
					});
					Thread.sleep(200);
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							shootingLayer.getChildren().clear();
						}
					});
					Thread.sleep(50);//Just to space it out.
					game.getGameMap().getEnemyMap().moveEnemies(game.getPlayer());
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							if(game.getPlayer().getPlayerHealth() <= 0) {
								end_lose(stage);
							}
							enemyMapLayer.getChildren().clear();
							Controller.setEnemyPlayer(game.getGameMap().getEnemyMap(), enemyMapLayer);
							healthCounter.setValue(game.getPlayer().getPlayerHealth());
						}
					});
					Thread.sleep(500);
				}while(game.getGameMap().getEnemyMap().checkForEnemiesPresent()==true && game.getPlayer().getPlayerHealth() > 0);
				game.incrementRound();//Round is going up.
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						roundCounter.setValue(game.getRound());
					}
				});
				startButton.setDisable(false);//You could make the task return something to set a timer on disable?
				return null;
			}
		});
		Thread newT = new Thread(thread);
	    newT.setDaemon(true);
	    newT.start();
	}
}
