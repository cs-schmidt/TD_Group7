package enemyManager;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import mapsManager.Maps;
import player.Player;

public class EnemyMapJUNIT {
	
		@Test
		public void checkEnemyPathLength() {
			Maps maps = new Maps();
			EnemyMap enemyMap1 = new EnemyMap(maps.getMap(0));
			assertEquals("Enemy path should have a length of 23 - testing 'enemyPathLength()'",23,enemyMap1.getEnemyPathLength());
			EnemyMap enemyMap2 = new EnemyMap(maps.getMap(1));
			assertEquals("Enemy path should have a length of 7 - testing 'enemyPathLength()'",7,enemyMap2.getEnemyPathLength());
			EnemyMap enemyMap3 = new EnemyMap(maps.getMap(2));
			assertEquals("Enemy path should have a length of 20 - testing 'enemyPathLength()'",20,enemyMap3.getEnemyPathLength());
		}

		@Test
		public void getLocationOfEnemySpawn() {
			Maps maps = new Maps();
			EnemyMap enemyMap1 = new EnemyMap(maps.getMap(0));
			enemyMap1.setEnemyBag(0);
			enemyMap1.spawnEnemy();
			assertEquals("Spawn should be at row 1 column 0 in enemyMap attribute of enemyMap1 - testing 'spawnEnemy()'",1,enemyMap1.enemyMap[1][0].getEnemyTag());
			EnemyMap enemyMap2 = new EnemyMap(maps.getMap(1));
			enemyMap2.setEnemyBag(0);
			enemyMap2.spawnEnemy();
			assertEquals("Spawn should be at row 1 column 0 in enemyMap attribute of enemyMap2 - testing 'spawnEnemy()'",1,enemyMap2.enemyMap[1][0].getEnemyTag());
			EnemyMap enemyMap3 = new EnemyMap(maps.getMap(2));
			enemyMap3.setEnemyBag(0);
			enemyMap3.spawnEnemy();
			assertEquals("Spawn should be at row 0 column 0 in enemyMap attribute of enemyMap3 - testing 'spawnEnemy()'",1,enemyMap3.enemyMap[0][0].getEnemyTag());
		}
		
		@Test
		public void didEnemiesMove1() {
			Player you = new Player(0);
			Maps maps = new Maps();
			EnemyMap enemyMap1 = new EnemyMap(maps.getMap(0));
			enemyMap1.setEnemyBag(0);
			enemyMap1.spawnEnemy();
			enemyMap1.moveEnemies(you);
			assertEquals("Spawn should be at row 1 column 1 in enemyMap attribute of enemyMap1 - testing 'moveEnemies()'",1,enemyMap1.enemyMap[1][1].getEnemyTag());
			EnemyMap enemyMap2 = new EnemyMap(maps.getMap(1));
			enemyMap2.setEnemyBag(0);
			enemyMap2.spawnEnemy();
			enemyMap2.moveEnemies(you);
			assertEquals("Spawn should be at row 1 column 1 in enemyMap attribute of enemyMap2 - testing 'moveEnemies()'",1,enemyMap2.enemyMap[1][1].getEnemyTag());
			EnemyMap enemyMap3 = new EnemyMap(maps.getMap(2));
			enemyMap3.setEnemyBag(0);
			enemyMap3.spawnEnemy();
			enemyMap3.moveEnemies(you);
			assertEquals("Spawn should be at row 0 column 1 in enemyMap attribute of enemyMap3 - testing 'moveEnemies()'",1,enemyMap3.enemyMap[0][1].getEnemyTag());
		}
		
		@Test
		public void didEnemiesMove4() {
			Player you = new Player(0);
			Maps maps = new Maps();
			EnemyMap enemyMap1 = new EnemyMap(maps.getMap(0));
			enemyMap1.setEnemyBag(0);
			enemyMap1.spawnEnemy();
			for(int i = 0; i < 4; i++)
				enemyMap1.moveEnemies(you);
			assertEquals("Spawn should be at row 3 column 2 in enemyMap attribute of enemyMap1 - testing 'moveEnemies()'",1,enemyMap1.enemyMap[3][2].getEnemyTag());
			EnemyMap enemyMap2 = new EnemyMap(maps.getMap(1));
			enemyMap2.setEnemyBag(0);
			enemyMap2.spawnEnemy();
			for(int i = 0; i < 4; i++)
				enemyMap2.moveEnemies(you);
			assertEquals("Spawn should be at row 3 column 2 in enemyMap attribute of enemyMap2 - testing 'moveEnemies()'",1,enemyMap2.enemyMap[3][2].getEnemyTag());
			EnemyMap enemyMap3 = new EnemyMap(maps.getMap(2));
			enemyMap3.setEnemyBag(0);
			enemyMap3.spawnEnemy();
			for(int i = 0; i < 4; i++)
				enemyMap3.moveEnemies(you);
			assertEquals("Spawn should be at row 0 column 5 in enemyMap attribute of enemyMap3 - testing 'moveEnemies()'",1,enemyMap3.enemyMap[0][4].getEnemyTag());
		}
		
}
