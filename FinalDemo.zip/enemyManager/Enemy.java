package enemyManager;
/**
 * This is the class responsible for the creation of Enemies.
 * @author ethan.schmidt1
 *
 */
public class Enemy {
	//Attributes
		/**
		 * This attribute is simply an integer representing the enemies health.
		 */
		private int enemyHealth;
		/**
		 * This attribute is simply an integer representing the enemies damage.
		 */
		private int enemyDamage;
		/**
		 * This attribute is simply an integer representing the enemies tag, which is used as an identifier for the object.
		 */
		private int enemyTag;
		/**
		 * This attribute is simply an integer representing the enemies value.
		 */
		private int enemyValue;
	//Constructors
		/**
		 * This is one of the constructors for a enemy object. It will take characters 'A','B','C' and will create <br>
		 * enemies each distinct in attributes from one another. If any other character is passed as an argument then it <br>
		 * will simply produce a enemy with all of its attributes set to 0.
		 * @param identifier :Takes a character('A','B','C' to create 3 differing enemies, and any other character to create <br>
		 * a enemy with all of its attributes set to 0).
		 */
		public Enemy(char identifier) {
			if(identifier == 'A') {
				enemyHealth = 7;
				enemyDamage = 1;
				enemyTag = 1;
				enemyValue = 1;//Adjust this for balance
			}
			
			else if(identifier == 'B') {
				enemyHealth = 12;
				enemyDamage = 2;
				enemyTag = 2;
				enemyValue = 2;//Adjust this for balance	
			}
			else if(identifier == 'C') {
				enemyHealth = 24;
				enemyDamage = 3;
				enemyTag = 3;
				enemyValue = 3;//Adjust this for balance	
			}
			else {
				enemyHealth = 0;
				enemyDamage = 0;
				enemyTag = 0;
				enemyValue = 0;//Dummy enemy is created
			}
		}
		/**
		 * Just a copy constructor.
		 * @param toCopy :Takes an enemy type object as an argument;
		 */
		protected Enemy(Enemy toCopy) {
			enemyHealth = toCopy.enemyHealth;
			enemyDamage = toCopy.enemyDamage;
			enemyTag = toCopy.enemyTag;
			enemyValue = toCopy.enemyValue;
		}
	//Methods
		//Getters
			/**
			 * This is a getter method that will get the health attribute value of an enemy.
			 * @return returns an integer representing the health of an enemy.
			 */
			public int getEnemyHealth() {
				int health = enemyHealth;
				return health;
			}
			/**
			 * This is a getter method that will get the damage attribute value of an enemy.
			 * @return returns an integer representing the damage of an enemy.
			 */
			public int getEnemyDamage() {
				int damage = enemyDamage;
				return damage;
			}
			/**
			 * This is a getter method that will get the tag attribute value of an enemy.
			 * @return returns an integer representing the tag of an enemy.
			 */
			public int getEnemyTag() {
				int tag = enemyTag;
				return tag;
			}
			/**
			 * This is a getter method that will get the value attribute of an enemy.
			 * @return returns an integer representing the value of an enemy.
			 */
			public int getEnemyValue() {
				int value = enemyValue;
				return value;
			}
		//Setters
			/**
			 *This is a setter method that can be used to subtract the enemy health by the integer passed in as an <br>
			 *argument. 
			 * @param damageRecieved :Takes an integer as an argument.
			 */
			public void setEnemyHealth(int damageRecieved) {
				if(damageRecieved >= 0) {
					enemyHealth = enemyHealth - damageRecieved;
				}
				else
					;//Do Nothing
			}
}
