package towerManager;
/**
 * This is the class responsible for the creation of towers.
 * @author ethan.schmidt1
 *
 */
public class Tower {//Now I'm thinking to add even more towers so that the outer tiles of a map won't just serve no purpose. 
	//Attributes
		/**
		 * This attribute is simply an integer representing the towers damage.
		 */
		private int towerDamage;
		/**
		 * This attribute is simply an integer representing the towers range.
		 */
		private int towerRange;
		/**
		 * This attribute is simply an integer representing the towers tag, which is used as an identifier for the object.
		 */
		private int towerTag;
		/**
		 * This attribute is simply an integer representing the towers cost.
		 */
		private int towerCost;
	//Constructors
		/**
		 * This is one of the constructors for a tower object. It will take characters 'A','B','C' and will create <br>
		 * towers each distinct in attributes from one another. If any other character is passed as an argument then it <br>
		 * will simply produce a tower with all of its attributes set to 0.
		 * @param identifier :Takes a character('A','B','C' to create 3 differing towers, and any other character to create <br>
		 * a tower with all of its attributes set to 0).
		 */
		Tower(char identifier){
			if(identifier == 'A') {
				towerDamage = 1;//Adjust this for balance
				towerRange = 1;//Adjust this for balance
				towerTag = 1;
				towerCost = 1;//Adjust this for balance
			}
			
			else if(identifier == 'B') {
				towerDamage = 2;//Adjust this for balance	
				towerRange = 2;//Adjust this for balance
				towerTag = 2;
				towerCost = 3;//Adjust this for balance	
			}
			else if(identifier == 'C') {
				towerDamage = 3;//Adjust this for balance	
				towerRange = 3;//Adjust this for balance
				towerTag= 3;
				towerCost = 5;//Adjust this for balance	
			}
			else {
				towerDamage = 0;
				towerRange = 0;
				towerTag = 0;
				towerCost = 0;//Dummy Tower is created
			}
		}
	//Methods
		//Getters
		/**
		 * This is a getter method that will get the damage attribute value of a tower.
		 * @return returns an integer representing the damage of a tower.
		 */
			public int getTowerDamage() {
				int damage = towerDamage;
				return damage;
			}
			/**
			 * This is a getter method that will get the range attribute value of a tower.
			 * @return returns an integer representing the range of a tower.
			 */
			public int getTowerRange() {
				int range = towerRange;
				return range;
			}
			/**
			 * This is a getter method that will get the tag attribute value of a tower.
			 * @return returns an integer representing the tag of a tower.
			 */
			public int getTowerTag() {
				int tag = towerTag;
				return tag;
			}
			/**
			 * This is a getter method that will get the cost attribute value of a tower.
			 * @return returns an integer representing the cost of a tower.
			 */
			public int getTowerCost() {
				int cost = towerCost;
				return cost;
			}
}
