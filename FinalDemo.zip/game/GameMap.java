package game;
import enemyManager.EnemyMap;
import mapsManager.Maps;
import towerManager.TowerMap;
public class GameMap {
	//Attributes
	public Maps maps =  new Maps();
	private TowerMap towerMap;
	private EnemyMap enemyMap;
	//e
	//Constructors
	public GameMap(int pickAStage){
		towerMap = new TowerMap(maps.getMap(pickAStage));
		enemyMap = new EnemyMap(maps.getMap(pickAStage));
	}
	//e
	//Methods
	public EnemyMap getEnemyMap() {
		return enemyMap;
	}
	public TowerMap getTowerMap() {
		return towerMap;
	}
	//e
}
