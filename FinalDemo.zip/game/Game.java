package game;

import player.Player;

public class Game {
	//Attributes
	public int round;
	private GameMap gameMap;
	private Player you;
	//e
	//Constructor
	public Game(int mapSelected, int startingPlayerFunds){
		gameMap = new GameMap(mapSelected);
		you = new Player(startingPlayerFunds);
	}
	//e
	//Methods
	public GameMap getGameMap() {
		return gameMap;
	}
	public Player getPlayer() {
		return you;
	}
	public int getRound() {
		return round;
	}
	public void incrementRound() {
		round++;
	}
	public void setRound(int x) {
		round = x;
	}
	//e
}
