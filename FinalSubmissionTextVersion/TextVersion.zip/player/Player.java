package player;
import java.util.Scanner;
/**
 * This is the player class which inherits from the PiggyBank class, thereby it achieves the dual functionality <br>
 * of giving the player class the status of being a live wallet.
 * @author ethan.schmidt1
 *
 */
public class Player extends PiggyBank{//I think the player can extend the PiggyBank.
	//Attributes
		/**
		 * This is just the attribute representing the players initial health in the game. It is initialized to 50.
		 */
		int playerHealth = 50;
	//Constructor
		/**
		 * This is the constructor for the player object which takes an integer argument. This is done in order to <br>
		 * initialize the player objects funds by calling the parent constructor.
		 * @param startingFunds
		 */
		public Player(int startingFunds){
			super(startingFunds);
		}
	//Methods
		//Getters
		/**
		 * Just a simple getter method to retrieve the current value of the 'playerHealth' attribute.
		 * @return returns and integer that is equivalent in value to the 'playerHealth' attribute. 
		 */
		public int getPlayerHealth() {
			int health = this.playerHealth;
			return health;
		}
		//Setters
		/**
		 *This is a setter method that can be used to subtract the player health by the integer passed in as an <br>
		 *argument. 
		 * @param damage :Takes an integer as an argument.
		 */
 		public void setPlayerHealth(int damage) {
			if(damage >= 0)
				playerHealth = playerHealth - damage;
			else
				;
		}
}