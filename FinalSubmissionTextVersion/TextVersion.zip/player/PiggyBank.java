package player;
/**
 * This class is responsible for tracking the economy of the game.
 * @author ethan.schmidt1
 *
 */
public class PiggyBank {
	//Attributes
	/**
	 * This is just an integer attribute for the current funds.
	 */
	private int funds = 0;
	//Constructor
		/**
		 * This constructor takes an integer argument to Initialize the value of the attribute 'funds'
		 * @param initializeFunds :Takes and integer argument to initialize the 'funds' attribute.
		 */
		public PiggyBank(int initializeFunds) {
			if(initializeFunds >= 0)
				funds = initializeFunds;
			else
				funds = 10;
		}
	//Methods
		//Verification Methods
			/**
			 * This is a method designed to check whether or not there are 'sufficient' funds to withdraw from <br>
			 *funds.
			 * @param amount :Takes an integer as an argument.
			 * @return returns a boolean as true or false depending on if there were ore weren't 'sufficient' funds.
			 */
			public boolean sufficientFunds(int amount) {//Exclusive use for withdrawal
				if((funds - amount) >= 0)
					return true;
				else
					return false;
			}
		//Getters
			/**
			 * A simple getter method to get a copy of the current funds.
			 * @return returns an integer equal to the 'funds' attribute.
			 */
			public int getFunds() {
				int aCopyOfFunds = funds;
				return aCopyOfFunds;
			}
		//Setters
			/**
			 * This is method will withdraw from funds given the player has enough money to fulfill the withdrawal <br>
			 * request.
			 * @param amount :Takes an integer argument representing the withdrawal amount desired.
			 */
			public void withdrawFunds(int amount) {//Towers will withdraw funds
				if(sufficientFunds(amount))
					funds -= amount;
				else
					;//Do nothing
			}
			/**
			 * This method provides the capability to deposit more currency in to the attribute 'funds'. 
			 * @param amount :Takes an integer as an argument for the amount desired to deposit.
			 */
			public void depositFunds(int amount) {//Enemies will deposit funds
				funds += amount;
			}
}