package game;

import player.Player;
/**
 * This is the game class, it essentially holds all the aspects required to make a game within itself.
 * @author ethan.schmidt1
 *
 */
public class Game {
	//Attributes
	/**
	 * This attribute is an integer type that represents the current round of a game.
	 */
	public int round;
	/**
	 * This attribute is a GameMap type that holds all of the "map-like" classes, i.e. Maps, TowerMap, and EnemyMap.
	 */
	private GameMap gameMap;
	/**
	 * This attribute is a Player type that will serve as the Player object for a game.
	 */
	private Player player;
	//e
	//Constructor
	/**
	 * This is a constructor that takes 2 arguments one is to instantiate its gameMap attribute and the other is to instantiate the player attribute.
	 * @param mapSelected :Takes an integer to instantiate the gameMap attribute.
	 * @param startingPlayerFunds :Takes an integer to instantiate the player attribute.
	 */
	public Game(int mapSelected, int startingPlayerFunds){
		gameMap = new GameMap(mapSelected);
		player = new Player(startingPlayerFunds);
	}
	//e
	//Methods
	/**
	 * This is just a getter method to retrieve the gameMap attribute;
	 * @return returns a the gameMap of this object.
	 */
	public GameMap getGameMap() {
		return gameMap;
	}
	/**
	 * This is just a getter method to retrieve the player attribute;
	 * @return returns a the player of this object.
	 */
	public Player getPlayer() {
		return player;
	}
	/**
	 * This is just a getter method to retrieve the round attribute;
	 * @return returns a the round of this object.
	 */
	public int getRound() {
		return round;
	}
	/**
	 * This is a setter method that just increments the round by 1;
	 */
	public void incrementRound() {
		round++;
	}
	/**
	 * This is a setter method that allows us to set the value of the round attribute if it is greater than or equal to 0.
	 * @param x
	 */
	public void setRound(int x) {
		if(x >= 0)
			round = x;
	}
	//e
}
