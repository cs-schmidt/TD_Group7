package mapsManager;
/**
 * This is a class that represents a map in our game.
 * @author ethan.schmidt1
 *
 */
public class Map {
	//Attributes
	/**
	 * This attribute is a 2D integer array that represents a maps layout.
	 */
		private int[][] grid;
		/**
		 * This attribute is a 2D integer array will store the coordinates of all the road index's held in a grid(2D integer array).
		 */
		private int[][] roadCoordinates;
		/**
		 * This is an attribute meant to hold the value of the grid attributes # of rows.
		 */
		private int rows;
		/**
		 * This is an attribute meant to hold the value of the grid attributes # of columns.
		 */
		private int columns;
	//Constructors
		/**
		 * This constructor will take a 2D integer array as an argument in order to establish all of its attributes/
		 * @param gridLoadedIn :Takes a 2D integer array.
		 */
		protected Map(int[][] gridLoadedIn) {
			grid = Grids.getGridCopy(gridLoadedIn);
			roadCoordinates = getRoadCoords(grid);
			rows = grid.length;
			columns = grid[0].length;
		}
		/**
		 * This is simply a copy constructor.
		 * @param toCopy :Takes a 'Map' type object.
		 */
		protected Map(Map toCopy) {
			grid = Grids.getGridCopy(toCopy.grid);
			roadCoordinates = Grids.getGridCopy(toCopy.roadCoordinates);
			rows = toCopy.rows;
			columns = toCopy.columns;
		}
	//Methods
		//Getters
			/**
			 * This is a simple getter method for the number of columns a 'Map' type object has.
			 * @return returns an integer equal to the number of columns.
			 */
			public int getMapColumns() {
				int numOfColumns = columns;
				return numOfColumns;
			}
			/**
			 * This is a simple getter method for the number of rows a 'Map' type object has.
			 * @return returns an integer equal to the number of rows.
			 */
			public int getMapRows() {
				int numOfRows = rows;
				return numOfRows;
			}
			/**
			 * This is a simple getter method for the 'roadCoordinates' of a 'Map' type object.
			 * @return returns a 2D integer array copy of the 'roadCoordinates'.
			 */
			public int[][] getMapRoad(){//Because of the method in grids we can just use this.
				return Grids.getGridCopy(roadCoordinates);
			}
			/**
			 * This is a simple getter method for the 'grid' of a 'Map' type object.
			 * @return returns a 2D integer array copy of the 'grid'.
			 */
			public int[][] getMapGrid(){
				return Grids.getGridCopy(grid);
			}
		//Methods used for handling the road
			/**
			 * Finds the length of a road given a 2D integer array of a give design (i.e. a 2D array with a 2 for the start of the road, <br>
			 * a 3 for the end of the road, and a single non intersecting line of 0's; where the grid can possess none of the values apart form <br>
			 * the road.).
			 * @param x :Takes a 2D integer array (of the given design).
			 * @return returns an integer representing the number of squares in a road on a grid.
			 */
			private int findRoadLength(int[][] x){
			int numOfElements = 0;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j]==2)
						numOfElements++;
					if(x[i][j]==0)
						numOfElements++;
					if(x[i][j]==3)
						numOfElements++;
				}
			}
			return numOfElements;
		}
			/**
			 * This will produce a 2D integer array that stores all the coordinates of a grids road squares in a sequenced 2D integer array.
			 * @param x :Takes a 2D integer array.
			 * @return returns a 2D integer array.
			 */
			private int[][] getRoadCoords(int[][] x){
			int[][] roadCoords = new int[findRoadLength(x)][2];
			boolean accounted = false;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j]==2) {
						roadCoords[0][0]= i;
						roadCoords[0][1]= j;
						accounted = true;
						break;
					}
				}
				if(accounted==true)
					break;
			}
			int lengthOfRoad = findRoadLength(x);
			int i = roadCoords[0][0];
			int j = roadCoords[0][1];
			int row = 1;
			for(int num = 0; num < lengthOfRoad;num++) {
				try {
					if(x[i][j+1] == 0) {
						x[i][j+1] = -1;
						roadCoords[row][0] = i;
						roadCoords[row][1] = j+1;
						row++;
						j=j+1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i][j-1] == 0){
						x[i][j-1] = -1;
						roadCoords[row][0]= i;
						roadCoords[row][1]= j-1;
						row++;
						j=j-1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i+1][j] == 0){
						x[i+1][j] = -1;
						roadCoords[row][0]= i+1;
						roadCoords[row][1]= j;
						row++;
						i=i+1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i-1][j] == 0){
						x[i-1][j] = -1;
						roadCoords[row][0]= i-1;
						roadCoords[row][1]= j;
						row++;
						i=i-1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
			}
			accounted = false;
			for(int p = 0; p < x.length; p ++) {
				for(int q = 0; q < x[p].length; q++) {
					if(x[p][q]==3) {
						roadCoords[lengthOfRoad-1][0]= p;
						roadCoords[lengthOfRoad-1][1]= q;
						accounted = true;
						break;
					}
				}
				if(accounted==true)
					break;
			}
		return roadCoords;
	}
}
