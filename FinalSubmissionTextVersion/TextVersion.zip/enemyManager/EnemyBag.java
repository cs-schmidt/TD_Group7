package enemyManager;
import java.util.ArrayList;
import java.util.Collections;
/**
 * This class is in charge of producing the diverse pool of enemies in a given round.
 * @author ethan.schmidt1
 *
 */
public class EnemyBag {
	//Attributes
		/**
		 * This ArrayList attribute will be what holds all of the enemies that are set to spawn in a given round.
		 */
		private ArrayList<Enemy> bagOfEnemies = new ArrayList<Enemy>();
	//Methods
		//Getters
			/**
			 * Just a simple getter Method to gain access to the 'bagOfEnemies' attribute.
			 * @return: returns an ArrayList of type 'Enemy'.
			 */
			public ArrayList<Enemy> getBag(){
				return bagOfEnemies;
			}
		//Setters
			/**
			 * This setter method will be in charge of filling our 'bagOfEnemies' with a diverse list of Enemies
			 * <br>and randomizing the order of the enemies spawn.
			 * @param round :Takes in the current round as an argument which is an integer.
			 */
			public void setEnemyBag(int round){//create a modifier here to make enemies harder.
				for(int a = 0; a < enemyFunctionA(round); a++) {
					Enemy enemyA = new Enemy('A');
					bagOfEnemies.add(enemyA);
				}
				for(int b = 0; b < enemyFunctionB(round); b++) {
					Enemy enemyB = new Enemy('B');
					bagOfEnemies.add(enemyB);
				}
				for(int c = 0; c < enemyFunctionC(round); c++) {
					Enemy enemyC = new Enemy('C');
					bagOfEnemies.add(enemyC);
				}
				Collections.shuffle(bagOfEnemies);
			}
		//Spawn functions
			/**
			 * A function that is in charge of spawning a certain number of 'A' type enemies on a given round.
			 * @param round :Takes in the current round as an argument which is an integer.
			 * @return: returns an integer indicating how many 'A' type enemies to spawn.
			 */
			private int enemyFunctionA(int round) {//Make this dynamic to A and based on the round number
				if(round <= 5) 
					return 3 + round;
				else
					return (int)(round * 0.5);
			}
			/**
			 * A function that is in charge of spawning a certain number of 'B' type enemies on a given round.
			 * @param round :Takes in the current round as an argument which is an integer.
			 * @return: returns an integer indicating how many 'B' type enemies to spawn.
			 */
			private int enemyFunctionB(int round) {//Make this dynamic to B and based on the round number
				if(round <= 10) 
					return (int)Math.floor(round);
				else
					return (int)(round*0.75);
				
			}
			/**
			 * A function that is in charge of spawning a certain number of 'C' type enemies on a given round.
			 * @param round :Takes in the current round as an argument which is an integer.
			 * @return: returns an integer indicating how many 'C' type enemies to spawn.
			 */
			private int enemyFunctionC(int round) {//Make this dynamic to C and based on the round number
				if(round <= 10) 
					return (int)Math.floor(round/2);
				else if(round <= 15)
					return (int)(round*0.75);
				else
					return round;
			}

}
