package enemyManager;
import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
public class EnemyBagJunit {
	
	@Test
	public void dynamicBagTest() {
		int initializeRound = 0;
		EnemyBag bag = new EnemyBag(initializeRound);
		assertEquals("Should spawn 3 enemies on round 0",3,bag.bagOfEnemies.size());
		initializeRound = 1;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should spawn 4 enemies on round 1",4,bag.bagOfEnemies.size());
		initializeRound = 2;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should spawn 6 enemies on round 2",6,bag.bagOfEnemies.size());
	}

	@Test
	public void dynamicEnemyTypeinBagTest() {
		int initializeRound = 0;
		EnemyBag bag = new EnemyBag(initializeRound);
		assertEquals("Should be false at round 0",false,bag.dynamicEnemySpawn());
		initializeRound = 1;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should be false at 1",false,bag.dynamicEnemySpawn());
		initializeRound = 2;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should be true at round 2",true,bag.dynamicEnemySpawn());
	}
	
	@Test
	public void dynamicEnemyHealth() {
		int initializeRound = 0;
		EnemyBag bag = new EnemyBag(initializeRound);
		assertEquals("Should be false at round 0",false,bag.enemyHealthChanged());
		initializeRound = 1;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should be false at 1",false,bag.enemyHealthChanged());
		initializeRound = 2;
		bag = new EnemyBag(initializeRound);
		assertEquals("Should be true at round 2",true,bag.enemyHealthChanged());
	}
	
}
