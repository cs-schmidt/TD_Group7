package playGame;

import enemyManager.EnemyMap;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class EnemyTiles extends Rectangle {
	public EnemyTiles(int rows, int columns, int state){
		setWidth(25);
		setHeight(25);
		setFill(Color.PINK);
		if(state == 0)
			setOpacity(50);
		else
			setOpacity(0);
		relocate(rows*Main.tileSize,columns*Main.tileSize);
	}
}
