package towerManager;
import java.util.Scanner;
import mapsManager.Map;
import enemyManager.*;
public class TowerMap {
	
	//Attributes
		public Tower[][] towerMap;
		int[][] towerTracker;
		
	//Constructor
		public TowerMap(Map map){
				this.towerMap = new Tower[map.getMapRows()][map.getMapColumns()];
					for(int row = 0; row < this.towerMap.length; row++) {
						for(int column = 0; column <  this.towerMap[0].length; column++ ) {
							TowerDummy dummyTower = new TowerDummy();
							this.towerMap[row][column] = dummyTower;
						}
					}
				this.towerTracker = new int[map.getMapRows()][map.getMapColumns()];
					for(int row = 0; row < this.towerTracker.length; row++) {
						for(int column = 0; column <  this.towerTracker[0].length; column++ ) {
							this.towerTracker[row][column] = map.getMapGrid()[row][column];
						}
					}
					for(int row = 0; row < this.towerTracker.length; row++) {
						for(int column = 0; column <  this.towerTracker[0].length; column++ ) {
							if(this.towerTracker[row][column] != 1) {
								this.towerTracker[row][column] = -1;
							}
						}
					}
					for(int row = 0; row < this.towerTracker.length; row++) {
						for(int column = 0; column <  this.towerTracker[0].length; column++ ) {
							if(this.towerTracker[row][column] == 1) {
								this.towerTracker[row][column] = 0;
							}
						}
					}
		}
		
	//Methods
		
		public void towerShoot(EnemyMap enemyMap){
			for(int row = 0; row < this.towerMap.length; row++) {
				for(int column = 0; column < this.towerMap[0].length; column++ ) {
					if(this.towerMap[row][column].getTowerTag() > 0) {
						for(int tile = enemyMap.getEnemyPathLength()- 2; tile >= 0; tile--) { 
							if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyTag() > 0) { //explore the +0.1 concept later.
								if(distance(enemyMap.enemyPath[tile][0],enemyMap.enemyPath[tile][1],row,column) <= ((double)this.towerMap[row][column].getTowerRange())*Math.pow(2.0,(1.0/2))+.01) {
									enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].setEnemyHealth(this.towerMap[row][column].getTowerDamage());
									if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyHealth() <= 0) {
										EnemyDummy dummyEnemy = new EnemyDummy();
										enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]] = dummyEnemy;
									}
								}
								break;
							}	
						}
					}
				}
			}
		}
		
		private double distance(double enemyRow, double enemyColumn, double towerRow, double towerColumn) {
			double distance = Math.pow((Math.pow(((double)enemyRow-(double)towerRow),2) + Math.pow(((double)enemyColumn-(double)towerColumn),2)),(((double)1)/2));
			return distance;
		}
		
		private int getDigitFromChar(char x) {
			if (x == 48) {return 0;}
			if (x == 49) {return 1;}
			if (x == 50) {return 2;}
			if (x == 51) {return 3;}
			if (x == 52) {return 4;}
			if (x == 53) {return 5;}
			if (x == 54) {return 6;}
			if (x == 55) {return 7;}
			if (x == 56) {return 8;}
			if (x == 57) {return 9;}
			else  {return 0;}
		}
		
		public void towerMapInfo() {
			System.out.println("*To place towers enter the coordinates in the form '01', where the first number represents the row and the second the column on the map.");
			System.out.println("*You may place towers on the tiles baring the symbol '#' or delete a tower on a tile that bares a letter.");
		}
		public void placeTower() { 
			if(placeTowerTestMethod() == true) {
				boolean areYouDone = false;
				System.out.println("you may pick rows between 0 and "+(towerMap.length - 1)+".");
				System.out.println("you may pick columns between 0 and "+(towerMap[0].length -1)+".");
				do {
					int[] coordinates = towerMakeOrDelete();
					if(towerTracker[coordinates[0]][coordinates[1]] > 0) {
						TowerDummy dummyTower = new TowerDummy();
						towerMap[coordinates[0]][coordinates[1]] = dummyTower;
						towerTracker[coordinates[0]][coordinates[1]] = 0;
						System.out.println("Tower has succesfully been deleted.");
					}
					else {
						int towerType = typeValid();
						if(towerType == 1) {
							TowerA towerA = new TowerA();
							towerMap[coordinates[0]][coordinates[1]] = towerA;
						    towerTracker[coordinates[0]][coordinates[1]] = towerA.getTowerTag();
						}
						if(towerType == 2) {
							TowerB towerB = new TowerB();
							towerMap[coordinates[0]][coordinates[1]] = towerB;
						    towerTracker[coordinates[0]][coordinates[1]] = towerB.getTowerTag();
						}
						if(towerType == 3) {
							TowerC towerC = new TowerC();
							towerMap[coordinates[0]][coordinates[1]] = towerC;
						    towerTracker[coordinates[0]][coordinates[1]] = towerC.getTowerTag();
						}
					}
					areYouDone = placeTowerTestMethod();
				}while(areYouDone == true);
			}
		}
		
		private int[] towerMakeOrDelete() {
			int[] coordinates = new int[2];
			boolean validInput = false;
			while(validInput ==false) {
				System.out.println("Enter the coordinates where you wish to place or delete a tower: ");
				Scanner input = new Scanner(System.in);
				String coords = input.nextLine();
				if(coords.length() == 2) {
					if(getDigitFromChar(coords.charAt(0)) < towerMap.length && getDigitFromChar(coords.charAt(0)) >= 0 ) {
						if(getDigitFromChar(coords.charAt(1))< towerMap[0].length && getDigitFromChar(coords.charAt(1)) >=0 ) {
							coordinates[0] = getDigitFromChar(coords.charAt(0));
							coordinates[1] = getDigitFromChar(coords.charAt(1));
							validInput = onRoad(coordinates);
						}
						else
							System.out.println("These coordiantes are out of the index.");
					}
					else
						System.out.println("These coordiantes are out of the index.");
				}
			}
			return coordinates;
		}
		
		private boolean onRoad(int[] coordinates) {
			boolean notOnRoad = true;
			if(towerTracker[coordinates[0]][coordinates[1]] == -1) {
				System.out.println("It appears you've placed a tower on the road, reenter valid coordinates.");
				notOnRoad = false;
			}
			else
				notOnRoad = true;
			return notOnRoad;
		}
		
		public boolean placeTowerTestMethod() {
			boolean aValidAnswer = false;
			boolean goAhead = false;
			System.out.println("Do you wish to place and/or delete any towers?(yes/no) ");
			Scanner input = new Scanner(System.in);
			String answer = input.nextLine();
			while(aValidAnswer == false) {
				if(answer.equals("yes") ^ answer.equals("no")) {
					aValidAnswer = true;
					if(answer.equals("yes"))
						goAhead = true;
					else
						goAhead = false;
				}
				else {
					System.out.println("Your answer must strictly be 'yes' or 'no'. Reenter 'yes' or 'no': ");
					input = new Scanner(System.in);
					answer = input.nextLine();
					if(answer.equals("yes") ^ answer.equals("no"))
						aValidAnswer = true;
					if(answer.equals("yes"))
						goAhead = true;
					else
						goAhead = false;
				}
			}
			return goAhead;
		}
		
		private int typeValid() {
			boolean validInput = false;
			int towerType = 0;
			while(validInput == false) {
				System.out.println("Place a tower of type 1, 2, or 3");
				Scanner input = new Scanner(System.in);
				String answer = input.nextLine();
				try {
					towerType = Integer.parseInt(answer);
					if(towerType == 1 ^ towerType == 2 ^ towerType == 3) {
						validInput = true;
					}
				}
				catch(Exception NumberFormatException) {
					System.out.println("You may only enter a single digit.");
				}
			}
			return towerType;
		}
}
