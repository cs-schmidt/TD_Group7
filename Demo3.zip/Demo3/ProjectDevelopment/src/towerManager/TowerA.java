package towerManager;

public class TowerA extends Tower{
	//Constructors
		TowerA(){
			super(1,1,1,1);
		}
}
