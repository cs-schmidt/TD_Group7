package towerManager;

public class TowerC extends Tower{
	//Constructors
		TowerC(){
			super(3,3,3,3);
		}
}
