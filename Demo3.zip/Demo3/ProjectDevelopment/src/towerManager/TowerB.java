package towerManager;

public class TowerB extends Tower{
	//Constructors
		TowerB(){
			super(2,2,2,2);
		}
}
