package towerManager;
public class Tower {
	//Attributes
		int towerDamage;
		int towerRange;
		int towerTag;
		int towerCost;

	//Constructors
		public Tower(int damage, int range, int tag, int cost){
			this.towerDamage = damage;
			this.towerRange = range;
			this.towerTag = tag;
			this.towerCost = cost;
		}
		
	//Methods
		
		//Getters
			public int getTowerDamage() {
				int damage = this.towerDamage;
				return damage;
			}
			
			public int getTowerRange() {
				int range = this.towerRange;
				return range;
			}
			
			public int getTowerTag() {
				int tag = this.towerTag;
				return tag;
			}
			
			private int getTowerCost() {
				int cost = this.towerCost;
				return cost;
			}
}
