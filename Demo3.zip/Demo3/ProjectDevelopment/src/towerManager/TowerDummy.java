package towerManager;
public class TowerDummy extends Tower {
	//Constructors
		public TowerDummy(){
				super(0,0,0,0);
			}
}
