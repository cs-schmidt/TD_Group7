package enemyManager;

public class EnemyDummy extends Enemy {
	//Constructor
		public EnemyDummy(){
				super(0,0,0,0);
			}
}
