package enemyManager;

import java.lang.Math;
public class EnemyB extends Enemy {
	
	//Constructors
		EnemyB(){
			super(4,1,1,1);
		}
		
		//Methods
			public static int bEnemiesForRound(int round) {
				return (int) Math.floor(round/2);
			}

}
