package enemyManager;

import java.util.ArrayList;
import java.util.Collections;
public class EnemyBag {
	
	//Attributes
		ArrayList<Enemy> bagOfEnemies = new ArrayList<Enemy>();
		
	//Constructors
		public EnemyBag(int round){
				this.bagOfEnemies = createBag(round);
			}
		
	//Methods
		private ArrayList<Enemy> createBag(int round){
			ArrayList<Enemy> bagOfEnemies = new ArrayList<Enemy>();
		
			for(int a = 0; a < EnemyA.aEnemiesForRound(round); a++) {
				Enemy enemyA = new EnemyA();
				bagOfEnemies.add(enemyA);
			}
			for(int b = 0; b < EnemyB.bEnemiesForRound(round); b++) {
				Enemy enemyB = new EnemyB();
				bagOfEnemies.add(enemyB);
			}
			for(int c = 0; c < EnemyC.cEnemiesForRound(round); c++) {
				Enemy enemyC = new EnemyC();
				bagOfEnemies.add(enemyC);
			}
			Collections.shuffle(bagOfEnemies); //this scrambles the array-list.
			return bagOfEnemies;
		}
		
		//Getters
			public ArrayList<Enemy> getBag(){
				return this.bagOfEnemies;
			}
}
