package enemyManager;
import mapsManager.Map;
import playGame.Player;
public class EnemyMap {
	
	//Attributes
		public Enemy[][] enemyMap;
		public int[][] enemyPath;
		
	//Constructor
		public EnemyMap(Map map){
			this.enemyMap = new Enemy[map.getMapRows()][map.getMapColumns()];
			for(int row = 0; row < this.enemyMap.length; row++) {
				for(int column = 0; column <  this.enemyMap[0].length; column++ ) {
					EnemyDummy dummyEnemy = new EnemyDummy();
					this.enemyMap[row][column] = dummyEnemy;
				}
			}
			this.enemyPath = map.getMapRoad();
		}
		
	//Methods
		//Other methods
				public boolean checkForEnemiesPresent() {
					boolean enemiesPresent = false;
					for(int i = 0; i < this.enemyMap.length; i++) {
						for(int j = 0; j < this.enemyMap[i].length; j++) {
							if(this.enemyMap[i][j].getEnemyTag() > 0) {
								enemiesPresent = true;
								break;
							}
						}
						if(enemiesPresent == true) {
							break;
						}
					}
					return enemiesPresent;
				}
		
		//Basically setters.
			public void spawnEnemy(EnemyBag EnemyBag) {//We'll do a counting system.
				int row = this.enemyPath[0][0];
				int column = this.enemyPath[0][1];
				this.enemyMap[row][column] = EnemyBag.getBag().get(0);
				EnemyBag.getBag().remove(0);
			}
			
			public void moveEnemies(Player player) {
				for(int row = this.enemyPath.length - 2; row >= 0; row--) {
					if(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]].getEnemyTag() > 0) {
						Enemy enemyCopied = new Enemy(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]]);
						this.enemyMap[this.enemyPath[row + 1][0]][this.enemyPath[row + 1][1]] = enemyCopied;
						EnemyDummy dummyEnemy = new EnemyDummy();
						this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]] = dummyEnemy;
						if(this.enemyMap[this.enemyPath[this.enemyPath.length-1][0]][this.enemyPath[this.enemyPath.length-1][1]].getEnemyTag() > 0){
							player.setPlayerHealth(this.enemyMap[this.enemyPath[this.enemyPath.length-1][0]][this.enemyPath[this.enemyPath.length-1][1]].getEnemyDamage());
							EnemyDummy dummyEnemyP = new EnemyDummy();
							this.enemyMap[this.enemyPath[this.enemyPath.length-1][0]][this.enemyPath[this.enemyPath.length-1][1]] = dummyEnemyP;
						}
					}
				}
			}
			
		//Getters
			public int getEnemyPathLength(){
				return this.enemyPath.length;
			}	
}
