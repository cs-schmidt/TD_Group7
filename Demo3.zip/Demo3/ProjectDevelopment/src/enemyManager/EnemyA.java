package enemyManager;

public class EnemyA extends Enemy{
	
	//Constructors
		EnemyA(){
			super(3,1,1,1);
		}
		
		//Methods
			public static int aEnemiesForRound(int round) {
				return 3 + round;
			}

}
