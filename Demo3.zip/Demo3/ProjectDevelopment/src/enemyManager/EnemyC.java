package enemyManager;

public class EnemyC extends Enemy {
	
	//Constructors
		EnemyC(){
			super(5,1,1,1);
		}

		//Methods
			public static int cEnemiesForRound(int round) {
				return (int) Math.floor(round/4);
			}
}
