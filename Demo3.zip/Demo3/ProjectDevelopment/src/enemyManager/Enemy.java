package enemyManager;

public class Enemy {
	
	//Attributes
		private int enemyHealth;
		private int enemyDamage;
		private int enemyTag;
		private int enemyValue;
		
	//Constructors
		protected Enemy(int health, int damage, int tag, int value) {
			this.enemyHealth = health;
			this.enemyDamage = damage;
			this.enemyTag = tag;
			this.enemyValue = value;
			
		}	
		
		public Enemy(Enemy toCopy) {
			this.enemyHealth = toCopy.enemyHealth;
			this.enemyDamage = toCopy.enemyDamage;
			this.enemyTag = toCopy.enemyTag;
			this.enemyValue = toCopy.enemyValue;
		}
		
	//Methods
		//Other methods
		
		//Getters
			//All of these are primitive types so they are encapsulated.
			public int getEnemyHealth() {
				int health = this.enemyHealth;
				return health;
			}
			
			public int getEnemyDamage() {
				int damage = this.enemyDamage;
				return damage;
			}
			
			public int getEnemyTag() {
				int tag = this.enemyTag;
				return tag;
			}
			
			public int getEnemyValue() {
				int value = this.enemyValue;
				return value;
			}
			
		//Setters
			public void setEnemyHealth(int damageRecieved) {
				this.enemyHealth = this.enemyHealth - damageRecieved;
			}
}
