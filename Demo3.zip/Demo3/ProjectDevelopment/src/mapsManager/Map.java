package mapsManager;
public class Map {
	//Attributes
		private int[][] grid;
		private int[][] roadCoordinates;
		private int rows;
		private int columns;
		
	//Constructors
		protected Map(int gridInListOfGridsAtIndex){
			Grids grids = new Grids();
			this.grid = grids.getGrid(gridInListOfGridsAtIndex);
			this.roadCoordinates = getRoadCoords(grids.getGrid(gridInListOfGridsAtIndex));
			this.rows = grids.getGrid(gridInListOfGridsAtIndex).length;
			this.columns = grids.getGrid(gridInListOfGridsAtIndex)[0].length;
			}
		
		protected Map(Map toCopy) {
			this.grid = Grids.copyGrid(toCopy.grid);
			this.roadCoordinates = Grids.copyGrid(toCopy.roadCoordinates);
			this.rows = toCopy.rows;
			this.columns = toCopy.columns;
		}
		
	//Methods
		//Getters
			public int getMapColumns() {
				int columns = this.columns;
				return columns;
			}
			
			public int getMapRows() {
				int rows = this.rows;
				return rows;
			}
			
			public int[][] getMapRoad(){
				int[][] road = new int[findRoadLength(this.grid)][2];
				for(int row = 0; row < road.length; row++) {
					for(int column = 0; column < road[row].length; column++) {
						road[row][column] =this.roadCoordinates[row][column];
					}
				}
				return road;
			}
			
			public int[][] getMapGrid(){
				int[][] grid = new int[this.rows][this.columns];
				for(int row = 0; row < this.grid.length; row++) {
					for(int column = 0; column < this.grid[row].length; column++) {
						grid[row][column] =this.grid[row][column];
					}
				}
				return grid;
			}
		
		
		//See map and road methods
			public void seeMap() {
				for(int row = 0;row < this.grid.length; row++) {
					for(int column = 0; column < this.grid[row].length; column++) {
						System.out.print(this.grid[row][column]+" ");
					}
					System.out.println();
				}
			}
			
			public void seeRoad() {
				for(int row = 0; row <this.roadCoordinates.length; row++) {
					for(int column = 0; column < this.roadCoordinates[row].length; column++) {
						System.out.print(this.roadCoordinates[row][column]+" ");
					}
					System.out.println();
				}
			}
		
		// For creating the 2D-integer road array.
		private int findRoadLength(int[][] x){
			int numOfElements = 0;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j]==2)
						numOfElements++;
					if(x[i][j]==0)
						numOfElements++;
					if(x[i][j]==3)
						numOfElements++;
				}
			}
			return numOfElements;
		}
		private int[][] getRoadCoords(int[][] x){
			int[][] roadCoords = new int[findRoadLength(x)][2];
			boolean accounted = false;
			for(int i = 0; i < x.length; i++) {
				for(int j = 0; j < x[i].length; j++) {
					if(x[i][j]==2) {
						roadCoords[0][0]= i;
						roadCoords[0][1]= j;
						accounted = true;
						break;
					}
				}
				if(accounted==true)
					break;
			}
			int lengthOfRoad = findRoadLength(x);
			int i = roadCoords[0][0];
			int j = roadCoords[0][1];
			int row = 1;
			for(int num = 0; num < lengthOfRoad;num++) {
				try {
					if(x[i][j+1] == 0) {
						x[i][j+1] = -1;
						roadCoords[row][0] = i;
						roadCoords[row][1] = j+1;
						row++;
						j=j+1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i][j-1] == 0){
						x[i][j-1] = -1;
						roadCoords[row][0]= i;
						roadCoords[row][1]= j-1;
						row++;
						j=j-1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i+1][j] == 0){
						x[i+1][j] = -1;
						roadCoords[row][0]= i+1;
						roadCoords[row][1]= j;
						row++;
						i=i+1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
				try {
					if(x[i-1][j] == 0){
						x[i-1][j] = -1;
						roadCoords[row][0]= i-1;
						roadCoords[row][1]= j;
						row++;
						i=i-1;
					}
				}
				catch(Exception ArrayIndexOutOfBoundsException){}
			}
			accounted = false;
			for(int p = 0; p < x.length; p ++) {
				for(int q = 0; q < x[p].length; q++) {
					if(x[p][q]==3) {
						roadCoords[lengthOfRoad-1][0]= p;
						roadCoords[lengthOfRoad-1][1]= q;
						accounted = true;
						break;
					}
				}
				if(accounted==true)
					break;
			}
		return roadCoords;
	}
}
