package mapsManager;
import java.util.ArrayList;
public class Grids {
	
	//Attributes
		protected ArrayList<int[][]> listOfGrids = new ArrayList<int[][]>();
		
	//Constructors
		//add all the grids in this one constructor.
		Grids(){
			listOfGrids.add(grid0());
			listOfGrids.add(grid1());
		}
		
	//Methods
		//Getters
			public int[][] getGrid(int gridAtIndex){
				int [][] copyOfGridAtIndex = copyGrid(listOfGrids.get(gridAtIndex));
				return copyOfGridAtIndex;
			}
		//Copiers
			public static int[][] copyGrid(int[][] gridToCopy){
				int[][] copyOfGrid = new int[gridToCopy.length][gridToCopy[0].length];
				for(int row = 0; row < gridToCopy.length; row++) {
					for(int column = 0; column < gridToCopy[0].length; column++) {
						copyOfGrid[row][column] = gridToCopy[row][column];
					}
				}
				return copyOfGrid;
			}
			
			
		//All grids
			private int[][] grid0(){
				int[][] someMap = new int[5][5];
					for(int i =0;i<someMap.length;i++) {
						for(int j =0;j<someMap[0].length;j++) {
							someMap[i][j] = 1;
						}
					}
					for(int i = 1;i==1;i++) {
						for(int j =0;j<3;j++) {
							someMap[i][j] = 0;
						}
					}
					for(int i = 1;i<4;i++) {
						for(int j =2;j==2;j++) {
							someMap[i][j] = 0;
						}
					}
					for(int i = 3;i==3;i++) {
						for(int j =2;j<5;j++) {
							someMap[i][j] = 0;
						}
					}
					someMap[1][0]=2;
					someMap[3][4]=3;
				return someMap;
		}
			
			private int[][] grid1(){
				int[][] someMap = new int[8][8];
					for(int i =0;i < someMap.length;i++) {
						for(int j =0;j < someMap[0].length;j++) {
							someMap[i][j] = 1;
						}
					}
					for(int i = 1;i==1;i++) {
						for(int j =0;j<3;j++) {
							someMap[i][j] = 0;
						}
					}
					for(int i = 1;i<4;i++) {
						for(int j =2;j==2;j++) {
							someMap[i][j] = 0;
						}
					}
					for(int i = 3;i==3;i++) {
						for(int j =2;j<5;j++) {
							someMap[i][j] = 0;
						}
					}
					someMap[1][0]=2;
					someMap[3][4]=3;
				return someMap;
		}
}
