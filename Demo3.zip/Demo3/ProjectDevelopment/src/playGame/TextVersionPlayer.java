package playGame;
public class TextVersionPlayer {

	public static void main(String[] args) {
		TextGameLogic.textGameRunner();
	}
}
