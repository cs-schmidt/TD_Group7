package playGame;
import enemyManager.EnemyBag;
import enemyManager.EnemyMap;
import mapsManager.Map;
import mapsManager.Maps;
import towerManager.TowerMap;

public class TextGameLogic {
	
	
	
	public static void textGameRunner() {
		Player you = new Player();
		Maps maps = new Maps();
		maps.seeLoadableMaps();
		int mapPicked = maps.pickMap();
		TowerMap towerMap = new TowerMap(maps.getMap(mapPicked));
		towerMap.towerMapInfo();
		int round = 0;
		do {
			EnemyBag bagOfEnemies = new EnemyBag(round);
			EnemyMap enemyMap = new EnemyMap(maps.getMap(mapPicked));
			towerMap.placeTower();
			displayBoard(towerMap, enemyMap, maps.getMap(mapPicked));
			enemyMap.spawnEnemy(bagOfEnemies);
			displayBoard(towerMap, enemyMap, maps.getMap(mapPicked));
			do {
				towerMap.towerShoot(enemyMap);
				displayBoard(towerMap, enemyMap, maps.getMap(mapPicked));
				enemyMap.moveEnemies(you);
				displayBoard(towerMap, enemyMap, maps.getMap(mapPicked));
				if(bagOfEnemies.getBag().size() > 0)
					enemyMap.spawnEnemy(bagOfEnemies);
					displayBoard(towerMap, enemyMap, maps.getMap(mapPicked));
			}while(enemyMap.checkForEnemiesPresent() == true && you.getPlayerHealth() > 0);
			round++;
		}while(you.getPlayerHealth() > 0);
		
	}
	
	private static void displayBoard(TowerMap towerMap, EnemyMap enemyMap, Map map) {
		String[][] display = new String[map.getMapRows()][map.getMapColumns()];
		for(int row = 0; row < map.getMapRows(); row++) {
			for(int column = 0; column < map.getMapColumns(); column++) {
				display[row][column] = "~";
			}
		}
		for(int row = enemyMap.enemyPath.length - 1; row >= 0; row--) {
			display[enemyMap.enemyPath[row][0]][enemyMap.enemyPath[row][1]] = "=";
		}
		for(int row = 0; row < towerMap.towerMap.length; row++) {
			for(int column = 0; column < towerMap.towerMap[0].length; column++) {
				if(towerMap.towerMap[row][column].getTowerTag() > 0)
					display[row][column] = "t";
			}
		}
		for(int row = 0; row < enemyMap.enemyMap.length; row++) {
			for(int column = 0; column < enemyMap.enemyMap[0].length; column++) {
				if(enemyMap.enemyMap[row][column].getEnemyTag() > 0)
					display[row][column] = "e";
			}
		}
		for(int row = 0; row < display.length; row++) {
			for(int column = 0; column < display[0].length; column++) {
				System.out.print(display[row][column] + " ");
			}
			System.out.println("");
		}
		System.out.println("");
	}

}
