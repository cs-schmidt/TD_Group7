package playGame;
import java.util.Scanner;
public class Player {
	
	//Attributes
		int playerHealth = 50;
		String playerName;
	
	//Constructor
		public Player(){
				System.out.print("Enter your name: ");
				Scanner input = new Scanner(System.in);
				String nameEntered = input.nextLine();
				this.playerName = nameEntered;
				System.out.println();
		}
		
	//Methods
		//Getters
		public int getPlayerHealth() {
			int health = this.playerHealth;
			return health;
		}
		
		//Setters
		public void setPlayerHealth(int damage) {
			this.playerHealth = this.playerHealth - damage;
		}

}