package towerManager;
import java.util.ArrayList;
import java.util.Scanner;
import player.Player;
import mapsManager.Grids;
import mapsManager.Map;
import enemyManager.*;
/**
 * This is a class that is simply responsible for the interaction of towers and the enemyMap.
 * @author ethan.schmidt1
 *
 */
public class TowerMap {
	//Attributes
		/**
		 * This attribute is just a 2D Array of type Tower that will hold our tower objects a given index's.
		 */
		public Tower[][] towerMap;
		/**
		 *  This attribute is just a 2D integer array that is intended to track towers at given index and <br>
		 *  their type.
		 */
		public int[][] towerTracker;
		/**
		 * This attribute is responsible to track the number of enemies the towers eliminate.
		 */
		public int killScore = 0;
		/**
		 * This is an integer array ArrayList that will store in each integer array the location of a tower that <br>
		 * shot, the location is shot to in the enemyMap, and its type.
		 */
		public ArrayList<int[]> shotTracker = new ArrayList<int[]>();

		//Constructor
		/**
		 * Just a TowerMap constructor that takes a 'Map' object as an argument to set the attributes to fit the map
		 * <br>the player will pick.
		 * @param map
		 */
		public TowerMap(Map map){
				towerMap = new Tower[map.getMapRows()][map.getMapColumns()];
					for(int row = 0; row < towerMap.length; row++) {
						for(int column = 0; column < towerMap[0].length; column++ ) {
							Tower dummyTower = new Tower('D');
							towerMap[row][column] = dummyTower;
						}
					}
				towerTracker = map.getMapGrid();
					for(int row = 0; row < towerTracker.length; row++) {
						for(int column = 0; column < towerTracker[0].length; column++ ) {
							if(towerTracker[row][column] == 1) {
								towerTracker[row][column] = 0;
							}
							else
								towerTracker[row][column] = -1;
						}
					}
		}
	//Methods
		//Give each tower a specific value return.
		/**
		 * This is a method that will give the player to delete a tower at some coordinate on the towerMap, It also
		 * <br>will update the player funds when a tower is deleted (which gives back a portion of the value). 
		 * @param row :Intended to take row of the towerMap as an argument.
		 * @param column :Intended to take column of the towerMap as an argument.
		 * @param player :Takes a 'player' object as an argument.
		 */
		public void deleteTowerGUI(int row, int column, Player player) {//Focus on these
			Tower tower = new Tower('D');
			player.depositFunds((towerMap[row][column].getTowerCost())/2);
			towerMap[row][column] = tower;
			towerTracker[row][column] = tower.getTowerTag();
		}
		/**
		 * This is a method that will place a tower at some coordinate on the towerMap, It also
		 * <br>will update the player funds when a tower is placed (which subtracts the towers value from player funds). 
		 * @param row :Intended to take row of the towerMap as an argument.
		 * @param column :Intended to take column of the towerMap as an argument.
		 * @param identifier : Takes a character 'A','B','C' to make distinct towers.
		 * @param player :Takes a 'player' object as an argument.
		 * 
		 */
		public void placeTowerGUI(int row, int column, char identifier, Player player) {//Update for dynamic placement.

			if(towerMap[row][column].getTowerTag() > 0) {
				//Do nothing, update for later in case of upgrade capabilities.
			}
			if(towerMap[row][column].getTowerTag() == 0) {
				if(player.sufficientFunds(new Tower(identifier).getTowerCost())) {
					Tower tower = new Tower(identifier);
					towerMap[row][column] = tower;
					player.withdrawFunds(tower.getTowerCost());
					towerTracker[row][column] = tower.getTowerTag();
				}
			}
		}
		/**
		 * Simply a getter Method for the 'killScore' attribute.
		 * @return returns an integer.
		 */
		public int getKillScore() {
			int KillScore = killScore;
			return KillScore;
		}
		/**
		 * Simply a getter Method for the 'towerTracker' attribute.
		 * @return returns a 2D integer array.
		 */
		public int[][] getTowerTracker(){
			return Grids.getGridCopy(towerTracker);
		}
		/**
		 * This method uses the 'enemyMap' and the 'player' to do 4 things: first make the towers shoot the enemies, second
		 * <br>increase the players funds if he/she kills an enemy, thirdly track kills, and lastly track which towers shot
		 * <br>and where.
		 * @param enemyMap :Takes the enemyMap as an argument.
		 * @param player :Takes the player object as an argument.
		 */
		public void towerShoot(EnemyMap enemyMap,Player player){//Improve this.
			for(int row = 0; row < this.towerMap.length; row++) {
				for(int column = 0; column < this.towerMap[0].length; column++ ) {
					if(this.towerMap[row][column].getTowerTag() > 0) {
						for(int tile = enemyMap.getEnemyPathLength()- 2; tile >= 0; tile--) { 
							if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyTag() > 0) { //explore the +0.1 concept later.
								if(distance(enemyMap.enemyPath[tile][0],enemyMap.enemyPath[tile][1],row,column) <= ((double)this.towerMap[row][column].getTowerRange())*Math.pow(2.0,(1.0/2))+.01) {
									//Here
									int[] shotData = new int[5];
									shotData[0] = row;
									shotData[1] = column;
									shotData[2] = enemyMap.enemyPath[tile][0];
									shotData[3] = enemyMap.enemyPath[tile][1];
									shotData[4] = towerMap[row][column].getTowerTag();
									shotTracker.add(shotData);
									//e
									enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].setEnemyHealth(this.towerMap[row][column].getTowerDamage());
									if(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyHealth() <= 0) {
										Enemy dummyEnemy = new Enemy('D');
										killScore++;
										player.depositFunds(enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]].getEnemyValue());
										enemyMap.enemyMap[enemyMap.enemyPath[tile][0]][enemyMap.enemyPath[tile][1]] = dummyEnemy;
									}
									break;
								}
							}	
						}
					}
				}
			}
		}
		/**
		 * Just a simple distance formula like you would have for calculating the distance of 2 points on a Cartesian plane.
		 * <br>The purpose of this method is to check if a tower is in range of shooting an enemy in a given map.
		 * @param enemyRow :Takes a enemies row (in the 'enemyMap').
		 * @param enemyColumn :Takes a enemies column (in the 'enemyMap').
		 * @param towerRow :Takes a towers row (in the 'towerMap').
		 * @param towerColumn :Takes a towers column (in the 'towerMap').
		 * @return: returns a double indicating the distance between 2 points.
		 */
		private double distance(double enemyRow, double enemyColumn, double towerRow, double towerColumn) {
			double distance = Math.pow((Math.pow(((double)enemyRow-(double)towerRow),2) + Math.pow(((double)enemyColumn-(double)towerColumn),2)),(((double)1)/2));
			return distance;
		}						
		
		//Methods specific to the text-based version.
			//1)
			/**
			 * This is a method specific to the text version that displays some information to the user about towers in the console.
			 */
			public static void towerMapInfo() {
				System.out.println("STATS OF TOWERS");
				System.out.println("Type_1 Tower: dmg = 2, range = 1, and cost = 1$");
				System.out.println("Type_2 Tower: dmg = 3, range = 2, and cost = 4$");
				System.out.println("Type_3 Tower: dmg = 5, range = 3, and cost = 8$");
				System.out.println("*HOW TO PLACE TOWERS: ");
				System.out.println(" To place towers enter the coordinates in the form '0,1', ");
				System.out.println(" where the first number represents the row and the second the column on the map.");
				System.out.println(" You may place towers on the tiles baring the symbol '#' or delete a tower on a tile that bares a letter.*(other than 's' or 'e')");
				System.out.println();
			}
			//2)
			/**
			 * This is a method that is specific to the text version that asks the user whether or no he/she desires to place towers or not.
			 * @return returns a boolean.
			 */
			public boolean placeTowerTestMethod() {
				boolean aValidAnswer = false;
				boolean goAhead = false;
				System.out.println("Do you wish to place and/or delete any towers?(yes/no) ");
				Scanner input = new Scanner(System.in);
				String answer = input.nextLine();
				while(aValidAnswer == false) {
					if(answer.equals("yes") ^ answer.equals("no")) {
						aValidAnswer = true;
						if(answer.equals("yes"))
							goAhead = true;
						else
							goAhead = false;
					}
					else {
						System.out.println("Your answer must strictly be 'yes' or 'no'. Reenter 'yes' or 'no': ");
						input = new Scanner(System.in);
						answer = input.nextLine();
						if(answer.equals("yes") ^ answer.equals("no"))
							aValidAnswer = true;
						if(answer.equals("yes"))
							goAhead = true;
						else
							goAhead = false;
					}
				}
				return goAhead;
			}
			//3)
			/**
			 * This method is specific to the text version and is used to translate user input integer to an array and this later facilitates the ability <br>
			 * to place or delete towers in combination with other methods.
			 * @return returns an integer array that is in a format that other methods will read
			 */
			private int[] getUserInput() {
				int[] coordinates = new int[2];
					coordinates[0] = -1;
					coordinates[1] = -1;
				boolean commaPresent = false;
				int commaIndex = 0;
				String num1 = "";
				String num2 = "";
				boolean userEnteredCorrectly = false;
				while(userEnteredCorrectly == false){
					System.out.println("Enter the coordinates where you wish to place or delete a tower: ");
					Scanner input = new Scanner(System.in);
					String coords = input.nextLine();
					for(int x = 0; x < coords.length(); x++) {
						if(coords.charAt(x) == ',') {
							commaPresent = true;
							commaIndex = x;
							break;
						}
					}
					if(commaPresent == true) {
						try {
							for(int x = 0; x < commaIndex; x++) {
								num1 += coords.charAt(x);
							}
							coordinates[0] = Integer.parseInt(num1);
						}
						catch(Exception e) {
		
						}
						try {
							for(int x = commaIndex + 1; x < coords.length(); x++) {
								num2 += coords.charAt(x);
							}
							coordinates[1] = Integer.parseInt(num2);
							}
						catch(Exception e) {
							
						}
					}
					else
						System.out.println("Your input is not what is expected. enter something like '0,0' as an input");
					if( (coordinates[0] >= 0 && coordinates[0] < towerMap.length) && (coordinates[1] >= 0 && coordinates[1] < towerMap[0].length)) {
						userEnteredCorrectly = onRoad(coordinates);
					}
				}
				return coordinates;
			}
			//4)
			/** 
			 * (text version exclusive) This method will see if a user tried to place a tower on the road. It takes an integer array in a size 2 form to look at the row and column of the <br>
			 * towerTracker attribute to see if a row and column correspond to a road tile in a game.
			 * @param coordinates :Takes an integer array.
			 * @return
			 */
			private boolean onRoad(int[] coordinates) {
				boolean notOnRoad = true;
				if(towerTracker[coordinates[0]][coordinates[1]] == -1) {
					System.out.println("It appears you've placed a tower on the road, reenter valid coordinates.");
					notOnRoad = false;
				}
				else
					notOnRoad = true;
				return notOnRoad;
			}
			//5)
			/**
			 * (text version exclusive) When the user places a tower this method will then be used to ask the user for the type of tower.
			 * @return returns an integer which is used to communicate the type of tower the user desired to place.
			 */
			private int typeValid() {
				boolean validInput = false;
				int towerType = 0;
				while(validInput == false) {
					System.out.println("Place a tower of type 1, 2, or 3");
					System.out.println("type 1 costs: 1$");
					System.out.println("type 2 costs: 4$");
					System.out.println("type 3 costs: 8$");
					Scanner input = new Scanner(System.in);
					String answer = input.nextLine();
					try {
						towerType = Integer.parseInt(answer);
						if(towerType == 1 ^ towerType == 2 ^ towerType == 3) {
							validInput = true;
						}
					}
					catch(Exception NumberFormatException) {
						System.out.println("You may only enter a single digit.");
					}
				}
				return towerType;
			}
			//6)
			/**
			 * (text version exclusive) This method will allow the user to place a tower at a location or delete one.
			 * @param player :Takes a Player type object as an argument to change a players funds if the build or destroy a tower.
			 */
			public void placeTower(Player player) { 
				if(placeTowerTestMethod() == true) {
					boolean areYouDone = false;
					System.out.println("you may pick rows between 0 and "+(towerMap.length - 1)+".");
					System.out.println("you may pick columns between 0 and "+(towerMap[0].length -1)+".");
					do {
						int[] coordinates = getUserInput();
						if(towerTracker[coordinates[0]][coordinates[1]] > 0) {
							Tower dummyTower = new Tower('D');
							towerMap[coordinates[0]][coordinates[1]] = dummyTower;
							towerTracker[coordinates[0]][coordinates[1]] = 0;
							System.out.println("Tower has succesfully been deleted.");
							player.depositFunds(towerTracker[coordinates[0]][coordinates[1]]);
							System.out.println("Funds: "+player.getFunds());
						}
						else {
							int towerType = typeValid();
							if(towerType == 1 && player.sufficientFunds(1)) {
								Tower towerA = new Tower('A');
								towerMap[coordinates[0]][coordinates[1]] = towerA;
							    towerTracker[coordinates[0]][coordinates[1]] = towerA.getTowerTag();
								System.out.println("Tower type A succesfully placed!");
								player.withdrawFunds(towerA.getTowerCost());
								System.out.println("Funds: "+player.getFunds());
							}
							else if(towerType == 2 && player.sufficientFunds(4)) {
								Tower towerB = new Tower('B');
								towerMap[coordinates[0]][coordinates[1]] = towerB;
							    towerTracker[coordinates[0]][coordinates[1]] = towerB.getTowerTag();
							    System.out.println("Tower type B succesfully placed!");
							    player.withdrawFunds(towerB.getTowerCost());
							    System.out.println("Funds: "+player.getFunds());
							}
							else if(towerType == 3 && player.sufficientFunds(8)) {
								Tower towerC = new Tower('C');
								towerMap[coordinates[0]][coordinates[1]] = towerC;
							    towerTracker[coordinates[0]][coordinates[1]] = towerC.getTowerTag();
							    System.out.println("Tower type C succesfully placed!");
							    player.withdrawFunds(towerC.getTowerCost());
							    System.out.println("Funds: "+player.getFunds());
							}
							else {
								System.out.println("You lack the sufficient funds for that action.");
							}
						}
						areYouDone = placeTowerTestMethod();
					}while(areYouDone == true);
				}
			}
}
