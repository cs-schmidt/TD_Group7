package game;
import enemyManager.EnemyMap;
import mapsManager.Maps;
import towerManager.TowerMap;
/**
 * This class is what serves as a holder of a games 3 map aspects, i.e. Maps, TowerMap, and EnemyMap.
 * @author ethan.schmidt1
 *
 */
public class GameMap {
	//Attributes
	/**
	 * This is the Maps attribute, which in the constructor of this class will be key to instantiate the towerMap and enemyMap attributes..
	 */
	public Maps maps =  new Maps();
	/**
	 * This is the TowerMap attribute.
	 */
	private TowerMap towerMap;
	/**
	 * This is the EnemyMap attribute.
	 */
	private EnemyMap enemyMap;
	//e
	//Constructors
	/**
	 * This constructor takes an integer argument to call the getMap() method on its maps attribute, it does this so it can then instantiate both of its <br>
	 * other attributes, those being towerMap and enemyMap.
	 * @param pickAStage :Takes an integer as an argument.
	 */
	public GameMap(int pickAStage){
		towerMap = new TowerMap(maps.getMap(pickAStage));
		enemyMap = new EnemyMap(maps.getMap(pickAStage));
	}
	//e
	//Methods
	/**
	 * This is a getter method that is used to return the enemyMap attribute of this class.
	 * @return returns the enemyMap attribute of this class.
	 */
	public EnemyMap getEnemyMap() {
		return enemyMap;
	}
	/**
	 * This is a getter method that is used to return the towerMap attribute of this class.
	 * @return returns the towerMap attribute of this class.
	 */
	public TowerMap getTowerMap() {
		return towerMap;
	}
	//e
}
