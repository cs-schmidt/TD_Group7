package GUIversion2;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * This class serves as the initial stage when you launch our game.
 * @author ethan.schmidt1
 *
 */
public class GUI extends Application{
	
	//All of the buttons and scenes we use in the start method
	Button start_button, Map1,Map2,Map3, info_button, back_button;
	Scene mainMenu, mapChooser;
	
	public static void main(String[] args) {
		launch(args);
		
	}
	
	/**
	 * This method is what displays the PopUp when the user clicks on the "info" button in the start menu.
	 */
	public static void mainmenu_display() {
		Stage window = new Stage();
		
		//MODALITY
		window.initModality(Modality.APPLICATION_MODAL);
		
		//SETTING UP LABEL AND BUTTON FUCTION
		Label label = new Label();
		label.setText("Created by: Edrick, Ethan, Alex, and Bruce.");
		label.setWrapText(true);
		Button closeButton = new Button("Very Interesting");
		closeButton.setOnAction(e -> window.close());
			
		//VBOX FOR BUTTON
		VBox layout = new VBox(10);
		layout.getChildren().addAll(closeButton, label);
		layout.setAlignment(Pos.CENTER);
		
		//IMAGING THE BACKGROUND
		Image background = new Image("info_background.png", true);
		ImageView node_background = new ImageView();
		node_background.setImage(background);
		
		//STACKPANE TO STACK BACKGROUND
		StackPane layout_p = new StackPane();
		layout_p.getChildren().addAll(node_background, layout);
		
		//SCENE CREATION
		Scene scene = new Scene(layout_p,200,200);
		window.setTitle("PRELUDE & CREDITS");
		window.setScene(scene);
		window.showAndWait();
	}
	
	public void start(Stage window) {
		window.setTitle("Picnic Defence Ver. 0.7.0"); 
		//SCENE1 CREATION
		//STARTBUTTON CREATION
		Image start_pic = new Image("start_b.png",300,100,false,true);
		ImageView start_node = new ImageView();
		start_node.setImage(start_pic);
		start_button = new Button();
		start_button.setPadding(Insets.EMPTY);
		start_button.setGraphic(start_node);
		start_button.setOnAction(e -> window.setScene(mapChooser));
		
		//INFOBUTTON ACTIVATION
		Image info_b = new Image("info_button.png", 100, 30, false, true);
		ImageView info_node = new ImageView();
		info_node.setImage(info_b);
		info_button = new Button();
		info_button.setPadding(Insets.EMPTY);
		info_button.setGraphic(info_node);
		info_button.setOnAction(e -> mainmenu_display());
		
		//BACKGROUND IMAGE
		Image background1 = new Image("mainMenu.png", 800,800,false,true);
		ImageView background_image1 = new ImageView(background1);
		
		//SCENE1 CREATION
		StackPane layout1 = new StackPane(); 
		VBox vbox = new VBox();
		vbox.setAlignment(Pos.CENTER);
		vbox.setSpacing(20);
		vbox.getChildren().addAll(start_button, info_button);
		layout1.getChildren().addAll(background_image1, vbox);
		mainMenu = new Scene(layout1, 800,700);
		
		//BACKGROUND
		Image background2 = new Image("map_background.png",800,800,false,true);
		ImageView background_image2 = new ImageView();
		background_image2.setImage(background2);
		
		//MAP SPRITES
		Image map1 = new Image("Map1.png", 150,150,false, true);
		ImageView map1_node = new ImageView(map1);
		Image map2 = new Image("Map2.png", 150,150,false, true);
		ImageView map2_node = new ImageView(map2);
		Image map3 = new Image("Map3.png", 150,150,false, true);
		ImageView map3_node = new ImageView(map3);
		
		//BUTTON FUNCTIONALITY

		Map1 = new Button();
		Map1.setGraphic(map1_node);
		Map1.setOnAction(e -> {
			try {
				Main.start(0);
				window.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		Map2 = new Button();
		Map2.setGraphic(map2_node);
		Map2.setOnAction(e -> {
			try {
				Main.start(1);
				window.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		Map3 = new Button();
		Map3.setGraphic(map3_node);
		Map3.setOnAction(e -> {
			try {
				Main.start(2);
				window.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		Image back_pic = new Image("backButton.png",50,30,false,true);
		ImageView node_back = new ImageView(back_pic);
		back_button = new Button();
		back_button.setGraphic(node_back);
		back_button.setPadding(Insets.EMPTY);
		back_button.setOnAction(e -> window.setScene(mainMenu));
		//back from map choosing screen
		
		//SCENE2 CREATION
		StackPane layout2 = new StackPane();
		HBox hbox = new HBox();
		VBox vbox2 = new VBox();
		
		vbox2.setAlignment(Pos.CENTER);
		vbox2.setSpacing(30);
		vbox2.getChildren().addAll(hbox, back_button);
		
		hbox.setSpacing(60);
		hbox.getChildren().addAll(Map1,Map2,Map3);
		hbox.setAlignment(Pos.CENTER);
		
		layout2.getChildren().addAll(background_image2,vbox2);
		mapChooser = new Scene(layout2,800,700);
				
		//sets first scene as mainMenu
		window.setScene(mainMenu);
		window.show();
			
		}
		
}
	
	
	
