package GUIversion2;
import enemyManager.EnemyMap;
import javafx.animation.TranslateTransition;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import mapsManager.Map;
import player.Player;
import towerManager.TowerMap;
/**
 * This is simply a class that hosts most of the methods that are used by the main class to play the game.
 * @author ethan.schmidt1
 *
 */
public class Controller {
	/**
	 * This IntegerProperty type attribute is used in the Main class to update the users coins as he plays the game.
	 */
	public static IntegerProperty dp;
	/**
	 * This method will modify a grid pane to make it display where towers are in the towerMap.
	 * @param towerMap :Takes a TowerMap type object as an argument.
	 * @param towerMapLayer :Takes a GridPane type object as an argument.
	 */
	public static void seeTowerLayer(TowerMap towerMap, GridPane towerMapLayer) {
		towerMapLayer.getChildren().clear();
		for(int row = 0; row < towerMap.towerMap.length; row++) {
			for(int column = 0; column < towerMap.towerMap[0].length; column++) {
				if(towerMap.towerTracker[row][column] == 1) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower1 = new Image("Tower01.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower1));
					towerMapLayer.add(towerIcon,column,row);
				}
				else if(towerMap.towerTracker[row][column] == 2) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower2 = new Image("Tower02.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower2));
					towerMapLayer.add(towerIcon,column,row);
				}
				else if(towerMap.towerTracker[row][column] == 3) {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					Image tower3 = new Image("Tower03.png",30,30,false,true);
					towerIcon.setFill(new ImagePattern(tower3));
					towerMapLayer.add(towerIcon,column,row);
				}
				else {
					Circle towerIcon = new Circle();
					towerIcon.setRadius(15);
					towerIcon.setOpacity(0.1);
					towerMapLayer.add(towerIcon,column,row);
				}
			}
		}
	}
	/**
	 * This method will modify a grid pane to make it display where enemies are in the enemyMap
	 * @param enemyMap :Takes a EnemyMap type object as an argument.
	 * @param enemyPlayer :Takes a GridPane type object as an argument.
	 */
	public static void seeEnemyPlayer(EnemyMap enemyMap,GridPane enemyPlayer) {//You could make the double for loop road specific.
		for(int row = 0; row < enemyMap.enemyMap.length; row++) {
			for(int column = 0; column < enemyMap.enemyMap[0].length; column++) {
				if(enemyMap.enemyMap[row][column].getEnemyTag() == 1) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug1 = new Image("Bug1.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug1));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else if(enemyMap.enemyMap[row][column].getEnemyTag() == 2) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug2 = new Image("Bug2.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug2));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else if(enemyMap.enemyMap[row][column].getEnemyTag() == 3) {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					Image Bug3 = new Image("Bug3.png",30,30,false,true);
					enemyMarker.setFill(new ImagePattern(Bug3));
					enemyPlayer.add(enemyMarker, column, row);
				}
				else {
					Rectangle enemyMarker = new Rectangle();
					enemyMarker.setWidth(30);
					enemyMarker.setHeight(30);
					enemyMarker.setFill(Color.RED);
					enemyMarker.setOpacity(0.1);
					enemyPlayer.add(enemyMarker, column, row);
				}
			}
		}
	}
	/**
	 * This method will produce a GridPane with a button for each square in a map where we can place towers. In addition it will also <br>
	 * modify the players funds and a IntegerProperty that can be used to update a label to display the players funds somewhere in the UI.
	 * @param map :Takes a Map type object as an argument.
	 * @param towerMap :Takes a TowerMap type object as an argument.
	 * @param towerMapLayerA :Takes a GridPane type object as an argument.
	 * @param player :Takes a Player type object as an argument.
	 * @param dp :Takes a IntegerProperty type object as an argument.
	 * @return returns a GridPane.
	 */
	public static GridPane createTowerMapInteractable(Map map, TowerMap towerMap, GridPane towerMapLayerA, Player player,IntegerProperty dp) {
		GridPane towerMapLayer = new GridPane();
		for(int row = 0; row < map.getMapGrid().length;row++) {
			for(int column = 0; column < map.getMapGrid()[0].length; column++) {
				if(map.getMapGrid()[row][column] == 1) {
					TowerMapButton towerMapButton = new TowerMapButton(row, column, towerMap, towerMapLayerA, player, dp);
					towerMapLayer.add(towerMapButton, column, row);
				}
				else {
					Rectangle spaceFiller = new Rectangle(30,30);//Here is a Change
					spaceFiller.setOpacity(0);
					towerMapLayer.add(spaceFiller, column, row);
				}
			}
		}
		return towerMapLayer;
	}
	/**
	 * This method serves to create a GridPane that will be formatted such that it will serve as a visual representation of a Map type object <br>
	 * that we pass in as an argument.
	 * @param map :Takes a Map type object as an argument.
	 * @return returns a GridpPane.
	 */
	public static GridPane createMapUnderlier(Map map) {
		GridPane mapUnderlier = new GridPane();
		for(int row = 0; row < map.getMapGrid().length;row++) {
			for(int column = 0; column < map.getMapGrid()[0].length; column++) {
				if(map.getMapGrid()[row][column] == 1) {
					BackgroundTile tile = new BackgroundTile();
					mapUnderlier.add(tile, column, row);
				}
				else {
					BackgroundTile tile = new BackgroundTile();
					Image road = new Image("road_2.png",30,30,false,true);
					tile.setFill(new ImagePattern(road));
					mapUnderlier.add(tile, column, row);
				}
				if(map.getMapGrid()[row][column] == 3) {
					BackgroundTile tile = new BackgroundTile();
					Image road = new Image("endOfRoad.png",30,30,false,true);
					tile.setFill(new ImagePattern(road));
					mapUnderlier.add(tile, column, row);
				}
			}
		}
		return mapUnderlier;
	}
	/**
	 * This method serves as a way to place towers via a window. When it is called the method will open a window and display buttons to both add and <br>
	 * remove towers from a TowerMap(logic side) and GridPane(visual side). In addition it comes equipt with the capability of updating a player objects <br>
	 * funds, and a IntegerProperty to update a labels text in the Main class, so as to show player funds in the GUI. 
	 * @param b :Takes a TowerMapButton type object in order to have coordinates.
	 * @param towerMapLayer :Takes a GridPane type argument.
	 * @param towerMap :Takes a TowerMap type argument.
	 * @param player :Takes a Player type argument.
	 * @param dp :Takes a IntegerProperty type argument.
	 */
	public static void towerPlacerWindow(TowerMapButton b, TowerMap towerMap, GridPane towerMapLayer, Player player, IntegerProperty dp) {
		Stage towerPlacerStage = new Stage();
		towerPlacerStage.setTitle("Towers");
		towerPlacerStage.initModality(Modality.APPLICATION_MODAL);
		
		HBox towerChoicePane = new HBox();
		//TOWER BUTTONS
		Image tower1_pic = new Image("Tower01.png", 60, 60, false, true);
		ImageView node_tower1 = new ImageView(tower1_pic);
		Button tower1 = new Button();
		tower1.setGraphic(node_tower1);
		tower1.setPadding(Insets.EMPTY);
		
		//tower1 action
		tower1.setOnAction(e->{
			if(player.getFunds() >= 1) {//Put the price of the towers here
				towerMap.placeTowerGUI(b.row, b.column,'A', player);
				dp.setValue(player.getFunds());
				Controller.seeTowerLayer(towerMap, towerMapLayer);
				towerPlacerStage.close();
			}
		});
		//e
		
		Image tower2_pic = new Image("Tower02.png", 60, 60, false, true);
		ImageView node_tower2 = new ImageView(tower2_pic);
		Button tower2 = new Button();
		tower2.setGraphic(node_tower2);
		tower2.setPadding(Insets.EMPTY);
		
		//tower2 action
		tower2.setOnAction(e->{
			if(player.getFunds() >= 2) {//Put the price of the towers here
				towerMap.placeTowerGUI(b.row, b.column,'B', player);
				dp.setValue(player.getFunds());
				Controller.seeTowerLayer(towerMap, towerMapLayer);
				towerPlacerStage.close();
			}
		});
		//e
		
		Image tower3_pic = new Image("Tower03.png", 60, 60, false, true);
		ImageView node_tower3 = new ImageView(tower3_pic);
		Button tower3 = new Button();
		tower3.setGraphic(node_tower3);
		tower3.setPadding(Insets.EMPTY);
		
		//tower3 action
		tower3.setOnAction(e->{
			if(player.getFunds() >= 3) {//Put the price of the towers here
				towerMap.placeTowerGUI(b.row, b.column,'C', player);
				dp.setValue(player.getFunds());
				Controller.seeTowerLayer(towerMap, towerMapLayer);
				towerPlacerStage.close();
			}
		});
		//e
		
		//Here make a 4th button to delete towers
		Button towerDelete = new Button("Sell");
		towerDelete.setPrefSize(60,60);
		
		//Delete action
		towerDelete.setOnAction(e->{
			//Put the price of the towers here
				towerMap.deleteTowerGUI(b.row, b.column, player);
				dp.setValue(player.getFunds());
				Controller.seeTowerLayer(towerMap, towerMapLayer);
				towerPlacerStage.close();
		});
		//e
				
		towerChoicePane.getChildren().addAll(tower1,tower2,tower3,towerDelete);
		Scene towerChoiceScene = new Scene(towerChoicePane);
		towerPlacerStage.setScene(towerChoiceScene);
		towerPlacerStage.show();
	}
	/**
	 * This Method will just produce a new Window that shows game info, it is meant to be tied to a running games info button so that a user may see <br>
	 * Tower info and Enemy info.
	 */
	public static void game_info() {
		Stage window = new Stage();
		
		//SETTING UP LABEL AND BUTTON FUCTIOn
		
			//The sizing is done here.
		Image enemy_b_pic = new Image("BugInfoButton.png",240,70,false,true);
		ImageView node_enemy = new ImageView(enemy_b_pic);
		Image towers_b_pic = new Image("TowerInfoButton.png",240,70,false,true);
		ImageView node_towers = new ImageView(towers_b_pic);
		
		Button enemy = new Button();
		enemy.setGraphic(node_enemy);
		enemy.setPadding(Insets.EMPTY);
		
		Button towers = new Button();
		towers.setGraphic(node_towers);
		towers.setPadding(Insets.EMPTY);
		
		Button game_play = new Button();
		game_play.setPadding(Insets.EMPTY);
				
		//VBOX FOR BUTTON and descriptions
		VBox layout = new VBox(20);
		layout.getChildren().addAll(enemy,towers,game_play);
		layout.setAlignment(Pos.CENTER);	
		
		
		//IMAGING THE BACKGROUND
		Image background = new Image("IB.png", 300, 300,false, true);//Here is where we change the background of the info PopUp
		ImageView node_background = new ImageView(background);
		
		//STACKPANE TO STACK BACKGROUND
		StackPane layout_p = new StackPane();
		layout_p.getChildren().addAll(node_background, layout);
		
		
		// SCENES
		Image back_pic = new Image("backButton.png",50,30,false,true);
		ImageView node_back = new ImageView(back_pic);
		
		//enemy scene
		Image info_bug = new Image("InfoBug.png",300,300,false,true);
		ImageView node_info_bug = new ImageView(info_bug);
		Button back1 = new Button();
		back1.setGraphic(node_back);
		back1.setPadding(Insets.EMPTY);
		Pane enemy_b = new Pane();                              
		enemy_b.getChildren().addAll(node_info_bug,back1);  //ADD IMAGE DESCRIPTION OF ENEMY FIRST
		back1.setLayoutX(120);
		back1.setLayoutY(270);	
		Scene enemy_s = new Scene(enemy_b,300,300);
		
		//tower info
		Image InfoTower = new Image("InfoTower.png",300,300,false,true);
		ImageView node_info_tower = new ImageView(InfoTower);
		Button back2 = new Button();
		back2.setGraphic(node_back);
		back2.setPadding(Insets.EMPTY);
		Pane towers_b = new Pane();
		towers_b.getChildren().addAll(node_info_tower,back2);                                    //ADD IMAGE DESCRIPTION OF TOWERS
		back2.setLayoutX(120);
		back2.setLayoutY(270);
		Scene towers_s = new Scene(towers_b,300,300);
		
		//SCENE CREATION
		Scene main_scene = new Scene(layout_p,300,300);
		
		back1.setOnAction(e -> window.setScene(main_scene));
		back2.setOnAction(e -> window.setScene(main_scene));
		enemy.setOnAction(e -> window.setScene(enemy_s));
		towers.setOnAction(e -> window.setScene(towers_s));
		
		window.setTitle("INFO");
		window.setScene(main_scene);
		window.showAndWait();
	}
	/**
	 * This method is used to see a shooting animation for towers on a pane.
	 * @param towerMap :Takes a TowerMap type object as an argument.
	 * @param seeShootLayer :Takes a Pane type object as an argument.
	 */
	public static void seeShootingLayer(TowerMap towerMap, Pane seeShootLayer) {
		for(int[] shotData: towerMap.shotTracker){
				Circle shot = new Circle(10);
				if (shotData[4] == 1) {
					shot.setFill(Color.RED);
					//play sound effect here
				}
				else if(shotData[4] == 2) {
					shot.setFill(Color.BLUE);
					//play sound effect here
				}
				else{
					shot.setFill(Color.PURPLE);
					//play sound effect here
				}
				shot.setLayoutX(30*shotData[1] + 15);
				shot.setLayoutY(30*shotData[0] + 15);
				//Lets try this for now...
				TranslateTransition shotPath = new TranslateTransition();
				shotPath.setDuration(Duration.millis(200));//Change speed here.
				shotPath.setToX(30*shotData[3] - 30*shotData[1]);
				shotPath.setToY(30*shotData[2] - 30*shotData[0]);
				shotPath.setNode(shot);
				seeShootLayer.getChildren().add(shot);
				shotPath.play();
		}
		towerMap.shotTracker.clear();
	}
}
/**
 * This class will basically serve as a means to place towers in a towerMap and put a display on a corresponding GridPane tile.
 * @author ethan.schmidt1
 *
 */
class TowerMapButton extends Button{//Button class
	//These are intended to mark the location of a button in a GridPane.
	int row;
	int column;
	/**
	 * This will create a button that is meant to correspond to a specific location on a grid pane and the facilitate the "towerPlacerWindow" method <br>
	 * to begin the foundations of being able to place towers in both the logic and GUI.
	 * @param row :Takes an integer type argument.
	 * @param column :Takes an integer type argument.
	 * @param towerMap :Takes a TowerMap type argument.
	 * @param towerMapLayer :Takes a GridPane type argument.
	 * @param player :Takes a Player type argument.
	 * @param dp :Takes an IntegerProperty type argument.
	 */
	TowerMapButton(int row, int column,TowerMap towerMap, GridPane towerMapLayer, Player player, IntegerProperty dp){
		setPrefSize(30,30);
		setOpacity(0.1);
		this.row = row;
		this.column = column;
		setOnMouseClicked(e->{
			if(e.getButton()==MouseButton.PRIMARY) {
				Controller.towerPlacerWindow(this, towerMap, towerMapLayer, player, dp);
			}
		});
	}
}
	/**
	 * Just a class that is used to build backGround tiles in a Pane.
	 * @author ethan.schmidt1
	 *
	 */
class BackgroundTile extends Rectangle{
	/**
	 * This constructor just produces a 30x30 rectangle that has a "grassLand" image as its Fill. It serves to create the visual representation of where a player <br>
	 * may place towers in the map.
	 */
	BackgroundTile(){
		Image grass = new Image("grassLand.png",29,29,false,true);
		setHeight(29);
		setWidth(29);
		setStrokeWidth(1);
		setStroke(Color.BLACK);
		setFill(new ImagePattern(grass));
	}
}