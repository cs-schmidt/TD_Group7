package enemyManager;
import mapsManager.Grids;
import mapsManager.Map;
import player.Player;
/** 
 * This class is responsible for representing enemy objects on a 2D array, and with this given state managing those enemies <br>
 * in the given grid.
 * @author ethan.schmidt1
 *
 */
public class EnemyMap extends EnemyBag{
	//Attributes
		/**
		 * This attribute is going to be where we store enemy objects in a 2D array.
		 */
		public Enemy[][] enemyMap;
		/**
		 * This attribute is a 2D integer array that encodes the road of a map for the enemies to follow on the 'enemyMap' <br>
		 * attribute.
		 */
		public int[][] enemyPath;
	//Constructor
		/**
		 * This constructor takes in a 'Map' object to initialize both attributes of this class. It initialize the 'enemyMap' <br>
		 * to be sized exactly as the 'Map' object passed and furthermore create the enemyPath based on the 'Map' objects
		 * 'roadCoordinates' attribute.
		 * @param map :Takes a 'Map' type argument to initialize the attributes.
		 */
		public EnemyMap(Map map){
			enemyMap = new Enemy[map.getMapRows()][map.getMapColumns()];
			for(int row = 0; row < enemyMap.length; row++) {
				for(int column = 0; column < enemyMap[0].length; column++ ) {
					Enemy dummyEnemy = new Enemy('D');
					enemyMap[row][column] = dummyEnemy;
				}
			}
			enemyPath = map.getMapRoad();
		}
	//Methods
			/**
			 * This method will simply check through the 'enemyMap' to see if any enemies with a tag > 0 exist and if so return <br>
			 * true and false otherwise.
			 * @return returns a boolean.
			 */
			public boolean checkForEnemiesPresent() {
				boolean enemiesPresent = false;
				for(int i = 0; i < this.enemyMap.length; i++) {
					for(int j = 0; j < this.enemyMap[i].length; j++) {
						if(this.enemyMap[i][j].getEnemyTag() > 0) {
							enemiesPresent = true;
							break;
						}
					}
					if(enemiesPresent == true) {
						break;
					}
				}
				return enemiesPresent;
			}
		//Basically setters.
			/**
			 * This method will take a enemy out of the 'enemyBag' and place it into the 'enemyMap' at the start of the road.
			 */
			public void spawnEnemy() {
				int row = enemyPath[0][0];
				int column = enemyPath[0][1];
				enemyMap[row][column] = getBag().get(0);
				getBag().remove(0);
			}
			/**
			 * This method will check through all the enemyPath coordinates in the enemyMap and move each enemy to the next coordinate.
			 * @param player :Takes a player argument so that the player will lose health if an enemy makes it to the end of the road.
			 */
			public void moveEnemies(Player player) {
				for(int row = enemyPath.length - 2; row >= 0; row--) {
					if(enemyMap[enemyPath[row][0]][enemyPath[row][1]].getEnemyTag() > 0) {
						Enemy enemyCopied = new Enemy(enemyMap[enemyPath[row][0]][enemyPath[row][1]]);
						enemyMap[enemyPath[row + 1][0]][enemyPath[row + 1][1]] = enemyCopied;
						Enemy dummyEnemy = new Enemy('D');
						enemyMap[enemyPath[row][0]][enemyPath[row][1]] = dummyEnemy;
						if(enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]].getEnemyTag() > 0){
							player.setPlayerHealth(enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]].getEnemyDamage());
							Enemy dummyEnemyP = new Enemy('D');
							enemyMap[enemyPath[enemyPath.length-1][0]][enemyPath[enemyPath.length-1][1]] = dummyEnemyP;
						}
					}
				}
			}
		//Getters
			/**
			 * This method will get the length of the enemyPath.
			 * @return returns an integer representing the length of the enemyPath.
			 */
			public int getEnemyPathLength(){
				return enemyPath.length;
			}	
			//Other
			public void enemyHealthDisplay() {
				System.out.print("Enemy health: ");
				for(int row = 0; row <  this.enemyPath.length - 1; row++) {
					if(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]].getEnemyTag() > 0) {
						System.out.print(this.enemyMap[this.enemyPath[row][0]][this.enemyPath[row][1]].getEnemyHealth() + " ");
					}
				}
			}
}
