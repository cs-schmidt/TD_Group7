package mapsManager;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * This is the Maps class which serves as a holder for all of the games maps.
 * @author ethan.schmidt1
 *
 */
public class Maps {
	//Attributes
		/**
		 * This attribute is basically just a 'Grids' type object which when instantiated will have a list of grids as an attribute <br>
		 * which are 2D integer arrays. 
		 */
		private Grids grids;
		/**
		 * This attribute is an ArrayList that contains objects of type 'Map'.
		 */
		private ArrayList<Map> listOfMaps = new ArrayList<Map>();
	//Constructors
		/**
		 * This constructor will instantiate the 'grids' attribute and the use that to initialize the 'listOfMaps' attribute.
		 */
		public Maps(){
			grids = new Grids();
			for(int[][] grid: grids.listOfGrids) {
				listOfMaps.add(new Map(grid));
			}
		}
	//Methods
		/**
		 * This method will get a map at an index in 'listOfMaps' and return a copy of it.
		 * @param mapInListOfMapsAtIndex :Takes an integer.
		 * @return returns a map.
		 */
		public Map getMap(int mapInListOfMapsAtIndex) {
			return new Map(listOfMaps.get(mapInListOfMapsAtIndex));
		}
		//Display text specific.**
			/** 
			 * This is a method that allows the user to see the loadable maps in the console version of the game.
			 */
			public void seeLoadableMaps() {
				System.out.println("Choose a map to load.");
				System.out.println("'s' represents the enemy spawn.");
				System.out.println("'~' represents enemy path.");
				System.out.println("'e' represents the end of the enemy path.");
				System.out.println("'#' represents where towers can be placed.");
				System.out.println("");
				for(int index = 0; index < listOfMaps.size(); index++) {
					System.out.println("Map "+index);
					displayMaps(listOfMaps.get(index));
					System.out.println("");
				}
			}
			/** 
			 * This is a method that allows the user to pick a map in the console version of the game.
			 */
			public int pickMap() {
				boolean inputIn = false;
				System.out.println("There are "+listOfMaps.size()+" maps, to pick one you must enter a number between 0 and "+(listOfMaps.size() - 1));
				Scanner input = new Scanner(System.in);
				String mapChoice = input.nextLine();
				while(inputIn == false) {
					try {
						inputIn = verifyMapExists(Integer.parseInt(mapChoice));
						while(verifyMapExists(Integer.parseInt(mapChoice)) == false) {
							System.out.println(Integer.parseInt(mapChoice)+" is a number that is out of the range, pick again.");
							input = new Scanner(System.in);
							mapChoice = input.nextLine();
						}
					}
					catch(Exception NumberFormatException){
						System.out.println("You may only enter a number!");
						System.out.println("reenter a valid number");
						input = new Scanner(System.in);
						mapChoice = input.nextLine();
					}
				}
				return Integer.parseInt(mapChoice);
			}
			/**
			 * This is a method that is exclusively used in the text version of the game. It basically is used to see if a map exist in the index you choose <br>
			 * in maps object.
			 * @param x :Takes an integer argument.
			 * @return returns a boolean stating whether or not the map existed.
			 */
			private boolean verifyMapExists(int x) {
				boolean verifyMapExists = false;
				for(int mapsInListOfMaps = 0; mapsInListOfMaps < listOfMaps.size(); mapsInListOfMaps++) {
					if(mapsInListOfMaps == x) {
						verifyMapExists = true;
						break;
					}
				}
				return verifyMapExists;
			}
			/**
			 * This is a method that is used to display a map objects grid in the console.
			 * @param map :Takes a Map type object.
			 */
			private void displayMaps(Map map) {
				for(int row = 0; row < map.getMapGrid().length; row++) {
					for(int column = 0; column < map.getMapGrid()[0].length; column++) {
						if(map.getMapGrid()[row][column] == 1) 
							System.out.print("#"+" ");
		
						else if(map.getMapGrid()[row][column] == 2)
							System.out.print("s"+" ");
						
						else if(map.getMapGrid()[row][column] == 3)
							System.out.print("e"+" ");
						
						else
							System.out.print("~"+" ");
					}
					System.out.println("");
				}
			}
}
